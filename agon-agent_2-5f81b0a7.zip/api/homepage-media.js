import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      let query = supabase.from('homepage_media').select('*').order('display_order', { ascending: true });
      if (req.query.active === 'true') query = query.eq('active', true);
      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const { title, description, media_type, file_url, file_name, mime_type, file_size, storage_path, active, display_order } = req.body;
      const { data, error } = await supabase.from('homepage_media').insert({ title, description, media_type, file_url, file_name, mime_type, file_size, storage_path, active, display_order }).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const { id, ...fields } = req.body;
      const { data, error } = await supabase.from('homepage_media').update(fields).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const id = req.query.id || req.body?.id;
      const { data: row } = await supabase.from('homepage_media').select('storage_path').eq('id', id).maybeSingle();
      const { error } = await supabase.from('homepage_media').delete().eq('id', id);
      if (error) throw error;
      if (row?.storage_path) {
        try { await supabase.storage.from('homepage-media').remove([row.storage_path]); } catch { /* noop */ }
      }
      return res.status(200).json({ ok: true });
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
