import supabase from './db-client.js';

const sanitize = (name) => String(name || 'upload').replace(/[^a-zA-Z0-9._-]+/g, '-').slice(0, 120);

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'POST') {
      const { fileName, fileBase64, contentType } = req.body;
      if (!fileName) return res.status(400).json({ error: 'fileName is required' });
      const path = `uploads/${Date.now()}-${sanitize(fileName)}`;
      if (fileBase64) {
        const buffer = Buffer.from(fileBase64, 'base64');
        const { error } = await supabase.storage.from('homepage-media').upload(path, buffer, { contentType: contentType || 'application/octet-stream', upsert: true });
        if (error) throw error;
        const { data: urlData } = supabase.storage.from('homepage-media').getPublicUrl(path);
        return res.status(200).json({ path, url: urlData.publicUrl });
      }
      const { data, error } = await supabase.storage.from('homepage-media').createSignedUploadUrl(path);
      if (error) throw error;
      const { data: urlData } = supabase.storage.from('homepage-media').getPublicUrl(path);
      return res.status(200).json({ path: data.path, token: data.token, publicUrl: urlData.publicUrl });
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
