export interface Service {
  id: number;
  name: string;
  category?: string | null;
  description?: string | null;
  price?: number | null;
  duration?: string | null;
  image_url?: string | null;
  featured?: boolean | null;
  active?: boolean | null;
}

export interface MediaItem {
  id: number;
  title?: string | null;
  description?: string | null;
  media_type?: string | null;
  file_url: string;
  file_name?: string | null;
  mime_type?: string | null;
  file_size?: number | null;
  storage_path?: string | null;
  active?: boolean | null;
  display_order?: number | null;
}

export interface Appointment {
  id: number;
  email: string;
  name: string;
  phone?: string | null;
  service_id?: number | null;
  service_name?: string | null;
  date: string;
  time: string;
  notes?: string | null;
  status?: string | null;
}

export interface SupportTicket {
  id: number;
  name?: string | null;
  email: string;
  subject?: string | null;
  category?: string | null;
  priority?: string | null;
  message?: string | null;
  status?: string | null;
  response?: string | null;
}

export interface ContactInquiry {
  id: number;
  name?: string | null;
  email: string;
  subject?: string | null;
  message?: string | null;
  status?: string | null;
  response?: string | null;
}

export interface Conversation {
  id: number;
  email?: string | null;
  name?: string | null;
  subject?: string | null;
  status?: string | null;
}

export interface ChatMessage {
  id: number;
  conversation_id: number;
  sender?: string | null;
  sender_name?: string | null;
  body?: string | null;
}
