export const formatPrice = (price?: number | null): string =>
  !price || price <= 0 ? "By Consultation" : `From $${Number(price).toLocaleString()}`;

export const formatMoney = (price?: number | null): string => {
  if (!price || price <= 0) return "\u2014";
  return `$${Number(price).toLocaleString()}`;
};

export const formatDate = (dateStr?: string | null): string => {
  if (!dateStr) return "";
  const [y, m, d] = dateStr.split("-").map(Number);
  if (!y || !m || !d) return dateStr;
  return new Date(y, m - 1, d).toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
  });
};

export const statusClasses = (status?: string | null): string => {
  const s = (status || "").toLowerCase();
  if (["confirmed", "responded", "completed", "closed"].includes(s))
    return "text-success border-success";
  if (["cancelled", "error"].includes(s)) return "text-danger border-danger";
  return "text-gold border-gold";
};

export const openLiveChat = (): void => {
  (window as unknown as { $chatway?: { openChatwayWidget?: () => void } }).$chatway?.openChatwayWidget?.();
};

export const formatFileSize = (bytes?: number | null): string => {
  if (!bytes || bytes <= 0) return "";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
};
