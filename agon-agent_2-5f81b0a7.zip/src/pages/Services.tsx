import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight, Clock, Star } from "lucide-react";
import Ornament from "../components/Ornament";
import { formatPrice } from "../lib/format";
import type { Service } from "../lib/types";

export default function Services() {
  const [services, setServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("All");

  useEffect(() => {
    fetch("/api/services")
      .then((r) => (r.ok ? r.json() : []))
      .then((d) => setServices(Array.isArray(d) ? d : []))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const categories = ["All", ...Array.from(new Set(services.map((s) => s.category).filter(Boolean) as string[]))];
  const list = filter === "All" ? services : services.filter((s) => s.category === filter);

  return (
    <div className="bg-royal pt-32 pb-20 px-6 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }} className="max-w-5xl mx-auto text-center mb-12">
          <div className="ornament-line mb-6 justify-center"><Ornament>Experiences</Ornament></div>
          <h1 className="font-display text-5xl sm:text-6xl text-cream mb-4">The Collection</h1>
          <p className="text-cream-dim max-w-xl mx-auto font-light">A curated suite of experiences, each composed with intention.</p>
        </motion.div>
        {loading ? (
          <p className="text-center text-cream-dim py-20 font-italiana tracking-[0.3em]">LOADING</p>
        ) : (
          <>
            <div className="flex flex-wrap justify-center gap-2 mb-12">
              {categories.map((c) => (
                <button key={c} onClick={() => setFilter(c)} className={`px-5 py-2 text-xs tracking-[0.2em] uppercase border transition-all ${filter === c ? "border-gold text-gold" : "border-gold-soft text-cream-dim hover:text-cream hover:border-gold"}`}>{c}</button>
              ))}
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
              {list.map((s, i) => (
                <motion.div key={s.id} initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-60px" }} transition={{ duration: 0.6, delay: (i % 3) * 0.1 }} className="group relative bg-card border-gold-soft border hover:border-gold overflow-hidden transition-all duration-500 flex flex-col">
                  <div className="aspect-[4/3] overflow-hidden relative">
                    {s.image_url && (<img src={s.image_url} alt={s.name} loading="lazy" className="w-full h-full object-cover opacity-50 group-hover:opacity-70 group-hover:scale-105 transition-all duration-700" />)}
                    {s.category && (<span className="absolute top-4 left-4 text-[10px] tracking-[0.25em] uppercase text-gold border border-gold px-3 py-1.5 bg-[#0a0908aa]">{s.category}</span>)}
                  </div>
                  <div className="p-7 flex flex-col flex-1">
                    <h3 className="font-display text-2xl text-cream mb-2">{s.name}</h3>
                    <p className="text-sm text-cream-dim mb-5 font-light leading-relaxed line-clamp-3">{s.description}</p>
                    <div className="flex items-center gap-4 mb-5 text-xs text-cream-dim">
                      {s.duration && (<span className="flex items-center gap-1"><Clock size={13} className="text-gold" /> {s.duration}</span>)}
                      {s.featured && (<span className="flex items-center gap-1 text-gold tracking-wider uppercase text-[10px]"><Star size={12} fill="#c9a961" /> Signature</span>)}
                    </div>
                    <div className="flex items-center justify-between pt-5 border-t border-gold-soft mt-auto">
                      <span className="font-display text-2xl text-cream">{formatPrice(s.price)}</span>
                      <Link to={`/booking?service=${s.id}`} className="btn-primary text-xs py-2.5 px-4">Reserve <ArrowRight size={14} /></Link>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
            <motion.div initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.7 }} className="max-w-3xl mx-auto text-center bg-card p-10 border-gold-soft border">
              <h3 className="font-display text-3xl text-cream mb-3">Seeking something else?</h3>
              <p className="text-cream-dim mb-6 font-light">We compose entirely bespoke experiences for our distinguished members. Speak with our concierge to design something uniquely yours.</p>
              <Link to="/contact" className="btn-secondary">Speak to Concierge</Link>
            </motion.div>
          </>
        )}
      </div>
    </div>
  );
}
