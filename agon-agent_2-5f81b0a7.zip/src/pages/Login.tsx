import { useEffect, useState } from "react";
import type { FormEvent } from "react";
import { Link, useNavigate } from "react-router-dom";
import { KeyRound, Loader2, Lock, Mail, User } from "lucide-react";
import Ornament from "../components/Ornament";
import { useAuth } from "../contexts/AuthContext";
import supabase from "../lib/supabase";
import { signInWithGoogle } from "../lib/googleAuth";

function GoogleIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24">
      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
      <path fill="#FBBC05" d="M5.84 14.1c-.22-.66-.35-1.36-.35-2.1s.13-1.44.35-2.1V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l3.66-2.84z" />
      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
    </svg>
  );
}

export default function Login() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!loading && user) navigate("/profile", { replace: true });
  }, [user, loading, navigate]);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password) { setError("Please enter your email and password."); return; }
    setError("");
    setInfo("");
    setBusy(true);
    try {
      if (mode === "signin") {
        const { error: err } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (err) throw err;
        navigate("/profile");
      } else {
        const { data, error: err } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: { data: { full_name: displayName.trim() || email.trim().split("@")[0] } },
        });
        if (err) throw err;
        if (data.session) { navigate("/profile"); }
        else { setInfo("Welcome to the House. Please check your email to confirm your account, then sign in."); }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Authentication failed. Please try again.");
    } finally {
      setBusy(false);
    }
  };

  const fillDemo = (demoEmail: string, demoPassword: string) => {
    setMode("signin");
    setEmail(demoEmail);
    setPassword(demoPassword);
    setError("");
    setInfo("");
  };

  return (
    <div className="bg-royal min-h-screen flex items-center justify-center pt-24 pb-12 px-6">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="ornament-line mb-2 justify-center"><Ornament>Members</Ornament></div>
          <h1 className="font-display text-4xl text-cream mb-2">{mode === "signin" ? "Welcome Back" : "Join the House"}</h1>
          <p className="text-cream-dim text-sm font-light">{mode === "signin" ? "Sign in to your private account." : "Create your private account."}</p>
        </div>
        <div className="bg-card p-8 border-gold-soft border">
          <form onSubmit={submit} className="space-y-4">
            {mode === "signup" && (
              <div>
                <label className="label-royal flex items-center gap-1"><User size={13} /> Display Name</label>
                <input value={displayName} onChange={(e) => setDisplayName(e.target.value)} placeholder="How shall we address you?" className="input-royal" />
              </div>
            )}
            <div>
              <label className="label-royal flex items-center gap-1"><Mail size={13} /> Email</label>
              <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" className="input-royal" />
            </div>
            <div>
              <label className="label-royal flex items-center gap-1"><Lock size={13} /> Password</label>
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022" className="input-royal" />
            </div>
            {error && <p className="text-sm text-danger">{error}</p>}
            {info && <p className="text-sm text-gold">{info}</p>}
            <button type="submit" disabled={busy} className="btn-primary w-full text-xs">
              {busy ? (<><Loader2 size={15} className="animate-spin" /> Please wait...</>) : mode === "signin" ? (<><KeyRound size={15} /> Sign In</>) : ("Create Account")}
            </button>
          </form>
          <div className="flex items-center gap-3 my-5">
            <span className="flex-1 h-px bg-gold-soft" />
            <span className="text-xs text-cream-dim">or</span>
            <span className="flex-1 h-px bg-gold-soft" />
          </div>
          <button onClick={() => signInWithGoogle("Charlotte Prestige")} className="btn-secondary w-full text-xs">
            <GoogleIcon /> Continue with Google
          </button>
          <p className="text-center mt-6 text-xs text-cream-dim">
            {mode === "signin" ? (
              <>New to the House?{" "}<button onClick={() => { setMode("signup"); setError(""); setInfo(""); }} className="text-cream-dim hover:text-gold transition-colors underline underline-offset-4">Create one</button></>
            ) : (
              <>Already a member?{" "}<button onClick={() => { setMode("signin"); setError(""); setInfo(""); }} className="text-cream-dim hover:text-gold transition-colors underline underline-offset-4">Sign in</button></>
            )}
          </p>
        </div>
        <div className="bg-card p-6 border-gold-soft border mt-4">
          <p className="label-royal text-center">Demo Access</p>
          <div className="space-y-2">
            <button onClick={() => fillDemo("customer@royal.com", "royal123")} className="w-full text-left text-xs text-cream-dim hover:text-gold transition-colors border border-gold-soft hover:border-gold px-4 py-3">Customer: customer@royal.com / royal123</button>
            <button onClick={() => fillDemo("admin@royal.com", "royal123")} className="w-full text-left text-xs text-cream-dim hover:text-gold transition-colors border border-gold-soft hover:border-gold px-4 py-3">Admin: admin@royal.com / royal123</button>
          </div>
        </div>
        <p className="text-center mt-6">
          <Link to="/" className="text-xs text-cream-dim hover:text-gold transition-colors tracking-wider">\u2190 Return to the House</Link>
        </p>
      </div>
    </div>
  );
}
