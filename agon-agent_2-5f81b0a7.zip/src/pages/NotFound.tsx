import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import Ornament from "../components/Ornament";

export default function NotFound() {
  return (
    <div className="bg-royal min-h-screen flex items-center justify-center px-6 pt-20">
      <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} className="max-w-xl w-full text-center">
        <div className="ornament-line mb-6 justify-center"><Ornament>404</Ornament></div>
        <h1 className="font-italiana text-gradient-gold text-7xl sm:text-8xl mb-4">404</h1>
        <h2 className="font-display text-4xl text-cream mb-4">A Wrong Turn</h2>
        <p className="text-cream-dim font-light mb-10">The path you sought has wandered beyond our halls. Allow us to guide you back.</p>
        <Link to="/" className="btn-primary">Return to the House</Link>
      </motion.div>
    </div>
  );
}
