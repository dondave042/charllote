import { useEffect, useMemo, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight, Calendar, Check, ChevronLeft, Clock, Loader2, Mail, MessageSquare, Phone, User } from "lucide-react";
import Ornament from "../components/Ornament";
import { useAuth } from "../contexts/AuthContext";
import { formatDate, formatMoney, formatPrice } from "../lib/format";
import type { Appointment, Service } from "../lib/types";

const TIMES = ["12:00 PM", "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM", "5:00 PM", "6:00 PM", "7:00 PM", "8:00 PM", "9:00 PM"];
const STEPS = ["Experience", "Date & Time", "Your Details", "Confirm"];

export default function Booking() {
  const [params] = useSearchParams();
  const { user, profile } = useAuth();
  const [services, setServices] = useState<Service[]>([]);
  const [step, setStep] = useState(1);
  const [serviceId, setServiceId] = useState<number | null>(null);
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [notes, setNotes] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [booked, setBooked] = useState<Appointment | null>(null);

  useEffect(() => {
    fetch("/api/services")
      .then((r) => (r.ok ? r.json() : []))
      .then((d) => {
        const list: Service[] = Array.isArray(d) ? d : [];
        setServices(list);
        const pre = params.get("service");
        if (pre && list.some((s) => String(s.id) === pre)) setServiceId(Number(pre));
      })
      .catch(() => {});
  }, [params]);

  useEffect(() => {
    if (user?.email) setEmail((v) => v || user.email || "");
    if (profile?.display_name) setName((v) => v || profile.display_name || "");
    if (profile?.phone) setPhone((v) => v || profile.phone || "");
  }, [user, profile]);

  const days = useMemo(() => {
    const out: { value: string; label: string; dow: string }[] = [];
    const now = new Date();
    for (let i = 1; i <= 21; i++) {
      const d = new Date(now);
      d.setDate(now.getDate() + i);
      out.push({
        value: `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`,
        label: d.toLocaleDateString("en-US", { month: "short", day: "numeric" }),
        dow: d.toLocaleDateString("en-US", { weekday: "short" }),
      });
    }
    return out;
  }, []);

  const selected = services.find((s) => s.id === serviceId) || null;

  const next = () => {
    setError("");
    if (step === 1 && !selected) { setError("Please select an experience to continue."); return; }
    if (step === 2 && (!date || !time)) { setError("Please select a date and time for your experience."); return; }
    if (step === 3 && (!name.trim() || !email.trim())) { setError("Please provide your name and email so our concierge may reach you."); return; }
    setStep((s) => Math.min(4, s + 1));
  };
  const back = () => { setError(""); setStep((s) => Math.max(1, s - 1)); };

  const confirm = async () => {
    if (!selected) return;
    setError("");
    setSubmitting(true);
    try {
      const res = await fetch("/api/appointments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email.trim(), name: name.trim(), phone: phone.trim(), service_id: selected.id, service_name: selected.name, date, time, notes: notes.trim() }),
      });
      if (!res.ok) throw new Error("booking failed");
      setBooked((await res.json()) as Appointment);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch {
      setError("Booking failed. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  if (booked) {
    return (
      <div className="bg-royal pt-32 pb-20 px-6 min-h-screen flex items-center justify-center">
        <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} className="max-w-2xl w-full bg-card p-10 md:p-14 border-gold border text-center">
          <div className="w-16 h-16 mx-auto mb-6 rounded-full flex items-center justify-center border border-gold">
            <Check size={28} className="text-gold" />
          </div>
          <div className="ornament-line mb-2 justify-center"><Ornament>Reservation Received</Ornament></div>
          <h1 className="font-display text-4xl text-cream mb-3">Thank You</h1>
          <p className="text-cream-dim font-light mb-8 max-w-md mx-auto">Thank you. A member of our concierge team will be in touch shortly to confirm the details of your experience.</p>
          <div className="text-left bg-[#0a0908aa] border border-gold-soft p-6 mb-8">
            <p className="text-xs text-cream-dim tracking-wider mb-4">Res. No. <span className="text-gold font-display text-base ml-1">CP-{String(booked.id).padStart(4, "0")}</span></p>
            <div className="space-y-2 text-sm text-cream">
              <p><span className="text-cream-dim">Experience: </span>{booked.service_name}</p>
              <p><span className="text-cream-dim">Date: </span>{formatDate(booked.date)}</p>
              <p><span className="text-cream-dim">Time: </span>{booked.time}</p>
              <p><span className="text-cream-dim">Investment: </span>{formatPrice(selected?.price)}</p>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/profile" className="btn-primary">View My Bookings</Link>
            <Link to="/" className="btn-secondary">Return Home</Link>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="bg-royal pt-32 pb-20 px-6 min-h-screen">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-10">
          <div className="ornament-line mb-6 justify-center"><Ornament>Reservations</Ornament></div>
          <h1 className="font-display text-5xl sm:text-6xl text-cream mb-4">Book an Experience</h1>
          <p className="text-cream-dim font-light">A few moments to begin your story.</p>
        </div>
        <div className="flex items-center justify-center mb-10 gap-2">
          {STEPS.map((label, i) => {
            const n = i + 1;
            const done = n < step;
            const current = n === step;
            return (
              <div key={label} className="flex items-center gap-2">
                <div className="flex items-center gap-2">
                  {done ? (
                    <div className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-display bg-gold text-[#0a0908]"><Check size={16} /></div>
                  ) : current ? (
                    <div className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-display border border-gold text-gold">{n}</div>
                  ) : (
                    <div className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-display border border-gold-soft text-cream-dim">{n}</div>
                  )}
                  <span className={`hidden sm:block text-xs tracking-wider ${current ? "text-gold" : "text-cream-dim"}`}>{label}</span>
                </div>
                {n < STEPS.length && (<span className={`w-6 sm:w-10 h-px mx-1 ${done ? "bg-gold" : "bg-gold-soft"}`} />)}
              </div>
            );
          })}
        </div>
        <motion.div key={step} initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }} className="bg-card p-8 md:p-10 border-gold-soft border">
          {step === 1 && (
            <div>
              <h2 className="font-display text-3xl text-cream mb-2">Choose Your Experience</h2>
              <p className="text-cream-dim mb-6 font-light text-sm">Select the offering that speaks to your intention.</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {services.map((s) => {
                  const active = s.id === serviceId;
                  return (
                    <button key={s.id} onClick={() => setServiceId(s.id)} className={`text-left p-5 border transition-all ${active ? "border-gold bg-gold-soft" : "border-gold-soft hover:border-gold"}`}>
                      <div className="flex items-start justify-between mb-2">
                        <span className="font-display text-lg text-cream">{s.name}</span>
                        {active && <Check size={18} className="text-gold flex-shrink-0 mt-1" />}
                      </div>
                      <p className="text-xs text-cream-dim mb-3 font-light line-clamp-2">{s.description}</p>
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-cream-dim flex items-center gap-1"><Clock size={12} className="text-gold" /> {s.duration}</span>
                        <span className="text-gold font-display text-base">{formatMoney(s.price)}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
          {step === 2 && (
            <div>
              <h2 className="font-display text-3xl text-cream mb-2">When Shall We Meet?</h2>
              <p className="text-cream-dim mb-6 font-light text-sm">Select a date and time for your experience.</p>
              <label className="label-royal flex items-center gap-2"><Calendar size={13} /> Date</label>
              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 gap-2 max-h-64 overflow-y-auto p-1 mb-8">
                {days.map((d) => (
                  <button key={d.value} onClick={() => setDate(d.value)} className={`p-3 border text-center transition-all ${date === d.value ? "border-gold bg-gold-soft" : "border-gold-soft hover:border-gold"}`}>
                    <span className="block text-[10px] uppercase tracking-wider text-cream-dim">{d.dow}</span>
                    <span className={`block text-sm mt-1 ${date === d.value ? "text-gold" : "text-cream"}`}>{d.label}</span>
                  </button>
                ))}
              </div>
              <label className="label-royal flex items-center gap-2"><Clock size={13} /> Time</label>
              <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-7 gap-2">
                {TIMES.map((t) => (
                  <button key={t} onClick={() => setTime(t)} className={`p-3 border text-center text-sm transition-all ${time === t ? "border-gold bg-gold-soft text-gold" : "border-gold-soft text-cream-dim hover:border-gold hover:text-cream"}`}>{t}</button>
                ))}
              </div>
            </div>
          )}
          {step === 3 && (
            <div>
              <h2 className="font-display text-3xl text-cream mb-2">Your Details</h2>
              <p className="text-cream-dim mb-6 font-light text-sm">A few details so our concierge may reach you discreetly.</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="label-royal flex items-center gap-2"><User size={13} /> Full Name</label>
                  <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Your full name" className="input-royal" />
                </div>
                <div>
                  <label className="label-royal flex items-center gap-2"><Mail size={13} /> Email</label>
                  <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" className="input-royal" />
                </div>
                <div className="md:col-span-2">
                  <label className="label-royal flex items-center gap-2"><Phone size={13} /> Phone <span className="text-cream-dim normal-case tracking-normal">(optional)</span></label>
                  <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+1 (555) 000-0000" className="input-royal" />
                </div>
                <div className="md:col-span-2">
                  <label className="label-royal flex items-center gap-2"><MessageSquare size={13} /> Notes <span className="text-cream-dim normal-case tracking-normal">(optional)</span></label>
                  <textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Special requests, preferences, occasions..." rows={4} className="input-royal resize-none" />
                </div>
              </div>
            </div>
          )}
          {step === 4 && selected && (
            <div>
              <h2 className="font-display text-3xl text-cream mb-2">Reservation Summary</h2>
              <p className="text-cream-dim mb-6 font-light text-sm">Please review your arrangement before confirming.</p>
              <div className="bg-[#0a0908aa] border border-gold-soft p-6 mb-6">
                <div className="text-sm text-cream space-y-1">
                  <p className="flex justify-between py-2 border-b border-gold-soft"><span className="text-cream-dim">Experience:</span><span className="font-display text-lg">{selected.name}</span></p>
                  <p className="flex justify-between py-2 border-b border-gold-soft"><span className="text-cream-dim">When:</span><span>{formatDate(date)} <span className="text-cream-dim">\u00b7 {time}</span></span></p>
                  <p className="flex justify-between py-2 border-b border-gold-soft"><span className="text-cream-dim">Guest:</span><span>{name} <span className="text-cream-dim">\u00b7 {email}</span></span></p>
                  <p className="flex justify-between py-2"><span className="text-cream-dim">Investment:</span><span className="text-gold font-display text-xl">{formatPrice(selected.price)}</span></p>
                </div>
              </div>
              <button onClick={confirm} disabled={submitting} className="btn-primary w-full">
                {submitting ? (<><Loader2 size={16} className="animate-spin" /> Confirming...</>) : ("Confirm Reservation")}
              </button>
              {error && <p className="mt-6 text-sm text-danger text-center">{error}</p>}
            </div>
          )}
          {step < 4 ? (
            <div>
              {error && <p className="mt-6 text-sm text-danger text-center">{error}</p>}
              <div className="flex items-center justify-between mt-6">
                <button onClick={back} disabled={step === 1} className="btn-ghost flex items-center gap-2 disabled:opacity-30"><ChevronLeft size={16} /> Back</button>
                <button onClick={next} className="btn-primary">Continue <ArrowRight size={16} /></button>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-start mt-6">
              <button onClick={back} className="btn-ghost flex items-center gap-2"><ChevronLeft size={16} /> Back</button>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
