import { useCallback, useEffect, useRef, useState } from "react";
import type { ChangeEvent, DragEvent } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Calendar, Check, ChevronDown, ChevronUp, ExternalLink, Eye, EyeOff, Film, Image as ImageIcon, Loader2, Lock, Mail, MessageCircle, Save, Send, Star, Ticket, Trash2, Upload, X } from "lucide-react";
import Ornament from "../components/Ornament";
import { useAuth } from "../contexts/AuthContext";
import supabase from "../lib/supabase";
import { formatDate, formatFileSize, statusClasses } from "../lib/format";
import type { Appointment, ChatMessage, ContactInquiry, Conversation, MediaItem, SupportTicket } from "../lib/types";

const tabs = [
  { key: "appointments", label: "Appointments", icon: Calendar },
  { key: "media", label: "Homepage Media", icon: ImageIcon },
  { key: "conversations", label: "Conversations", icon: MessageCircle },
  { key: "inquiries", label: "Inquiries", icon: Mail },
  { key: "tickets", label: "Tickets", icon: Ticket },
];

const appointmentStatuses = ["pending", "confirmed", "completed", "cancelled"];
const inquiryStatuses = ["new", "responded", "closed"];
const ticketStatuses = ["open", "responded", "closed"];
const conversationStatuses = ["open", "closed"];

interface QueuedFile {
  key: string;
  file: File;
  previewUrl: string;
  mediaType: "image" | "video";
  title: string;
  description: string;
  status: "ready" | "uploading" | "done" | "error";
  progress: string;
  error: string;
}

const fileToBase64 = (file: File): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(",")[1] || "");
    reader.onerror = () => reject(new Error("read failed"));
    reader.readAsDataURL(file);
  });

const selectStyle = { width: "auto", padding: "0.5rem 0.75rem" } as const;

export default function Admin() {
  const { profile, isAdmin, loading } = useAuth();
  const [activeTab, setActiveTab] = useState("appointments");
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [inquiries, setInquiries] = useState<ContactInquiry[]>([]);
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [media, setMedia] = useState<MediaItem[]>([]);
  const [dataLoading, setDataLoading] = useState(true);
  const [selectedConvo, setSelectedConvo] = useState<number | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [reply, setReply] = useState("");
  const [replying, setReplying] = useState(false);
  const [selectedInquiry, setSelectedInquiry] = useState<number | null>(null);
  const [inquiryResponse, setInquiryResponse] = useState("");
  const [selectedTicket, setSelectedTicket] = useState<number | null>(null);
  const [ticketResponse, setTicketResponse] = useState("");
  const [queue, setQueue] = useState<QueuedFile[]>([]);
  const [publishing, setPublishing] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [success, setSuccess] = useState("");
  const [pageError, setPageError] = useState("");
  const [busyId, setBusyId] = useState<number | null>(null);
  const [deletingId, setDeletingId] = useState<number | null>(null);
  const [edits, setEdits] = useState<Record<number, { title: string; description: string; display_order: number }>>({});
  const fileInput = useRef<HTMLInputElement>(null);

  const loadAll = useCallback(async () => {
    try {
      const [a, c, ci, t, m] = await Promise.all([
        fetch("/api/appointments").then((r) => (r.ok ? r.json() : [])),
        fetch("/api/conversations").then((r) => (r.ok ? r.json() : [])),
        fetch("/api/contact").then((r) => (r.ok ? r.json() : [])),
        fetch("/api/support").then((r) => (r.ok ? r.json() : [])),
        fetch("/api/homepage-media").then((r) => (r.ok ? r.json() : [])),
      ]);
      setAppointments(Array.isArray(a) ? a : []);
      setConversations(Array.isArray(c) ? c : []);
      setInquiries(Array.isArray(ci) ? ci : []);
      setTickets(Array.isArray(t) ? t : []);
      setMedia(Array.isArray(m) ? m : []);
    } catch { /* noop */ } finally { setDataLoading(false); }
  }, []);

  useEffect(() => {
    if (!loading && isAdmin) loadAll();
    if (!loading && !isAdmin) setDataLoading(false);
  }, [loading, isAdmin, loadAll]);

  const loadMessages = useCallback(async (convoId: number) => {
    try {
      const res = await fetch(`/api/messages?conversation_id=${convoId}`);
      if (res.ok) setMessages(await res.json());
    } catch { /* noop */ }
  }, []);

  useEffect(() => { if (selectedConvo) loadMessages(selectedConvo); }, [selectedConvo, loadMessages]);

  const sendReply = async (e: { preventDefault: () => void }) => {
    e.preventDefault();
    if (!reply.trim() || !selectedConvo) return;
    setReplying(true);
    try {
      const res = await fetch("/api/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ conversation_id: selectedConvo, sender: "concierge", sender_name: profile?.display_name || "Concierge", body: reply.trim() }),
      });
      if (res.ok) {
        setReply("");
        loadMessages(selectedConvo);
        fetch("/api/conversations").then((r) => (r.ok ? r.json() : [])).then((d) => setConversations(Array.isArray(d) ? d : []));
      }
    } catch { /* noop */ } finally { setReplying(false); }
  };

  const setAppointmentStatus = async (id: number, status: string) => {
    await fetch("/api/appointments", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, status }) });
    loadAll();
  };
  const deleteAppointment = async (id: number) => {
    if (window.confirm("Delete this reservation?")) {
      await fetch(`/api/appointments?id=${id}`, { method: "DELETE" });
      loadAll();
    }
  };
  const respondInquiry = async () => {
    if (!selectedInquiry || !inquiryResponse.trim()) return;
    await fetch("/api/contact", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: selectedInquiry, status: "responded", response: inquiryResponse.trim() }) });
    setInquiryResponse("");
    loadAll();
  };
  const setInquiryStatus = async (id: number, status: string) => {
    await fetch("/api/contact", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, status }) });
    loadAll();
  };
  const respondTicket = async () => {
    if (!selectedTicket || !ticketResponse.trim()) return;
    await fetch("/api/support", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: selectedTicket, status: "responded", response: ticketResponse.trim() }) });
    setTicketResponse("");
    loadAll();
  };
  const setTicketStatus = async (id: number, status: string) => {
    await fetch("/api/support", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, status }) });
    loadAll();
  };
  const setConvoStatus = async (id: number, status: string) => {
    await fetch("/api/conversations", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, status }) });
    loadAll();
  };

  const addFiles = (list: FileList | File[]) => {
    setSuccess("");
    setPageError("");
    const files = Array.from(list);
    if (files.length === 0) return;
    const queued: QueuedFile[] = files.map((f, i) => {
      const base = f.name.replace(/\.[^.]+$/, "").replace(/[-_]+/g, " ").trim() || "Untitled";
      return { key: `${Date.now()}-${i}-${f.name}`, file: f, previewUrl: URL.createObjectURL(f), mediaType: f.type.startsWith("video") ? "video" : "image", title: base.charAt(0).toUpperCase() + base.slice(1), description: "", status: "ready" as const, progress: "", error: "" };
    });
    setQueue((prev) => [...prev, ...queued]);
  };
  const updateQueued = (key: string, patch: Partial<QueuedFile>) => setQueue((prev) => prev.map((q) => (q.key === key ? { ...q, ...patch } : q)));
  const removeQueued = (key: string) => {
    setQueue((prev) => {
      const found = prev.find((q) => q.key === key);
      if (found) URL.revokeObjectURL(found.previewUrl);
      return prev.filter((q) => q.key !== key);
    });
  };

  const uploadOne = async (q: QueuedFile, order: number): Promise<boolean> => {
    updateQueued(q.key, { status: "uploading", progress: "Preparing upload...", error: "" });
    const file = q.file;
    let storagePath = "";
    let publicUrl = "";
    try {
      const prep = await fetch("/api/media-upload", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ fileName: file.name, contentType: file.type || "application/octet-stream", fileSize: file.size }) });
      if (!prep.ok) throw new Error("Could not prepare upload");
      const { path, token, publicUrl: url } = await prep.json();
      storagePath = path;
      publicUrl = url;
      updateQueued(q.key, { progress: "Uploading file..." });
      const { error } = await supabase.storage.from("homepage-media").uploadToSignedUrl(path, token, file);
      if (error) throw error;
    } catch (err) {
      if (file.size <= 4 * 1024 * 1024) {
        try {
          updateQueued(q.key, { progress: "Retrying via direct transfer..." });
          const base64 = await fileToBase64(file);
          const fb = await fetch("/api/media-upload", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ fileName: file.name, fileBase64: base64, contentType: file.type || "application/octet-stream" }) });
          if (!fb.ok) throw new Error("Fallback upload failed");
          const data = await fb.json();
          storagePath = data.path;
          publicUrl = data.url;
        } catch {
          updateQueued(q.key, { status: "error", error: err instanceof Error ? err.message : "Upload failed" });
          return false;
        }
      } else {
        updateQueued(q.key, { status: "error", error: err instanceof Error ? err.message : "Upload failed" });
        return false;
      }
    }
    updateQueued(q.key, { progress: "Publishing to homepage..." });
    try {
      const save = await fetch("/api/homepage-media", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ title: q.title.trim() || file.name, description: q.description.trim(), media_type: q.mediaType, file_url: publicUrl, file_name: file.name, mime_type: file.type || null, file_size: file.size, storage_path: storagePath, active: true, display_order: order }) });
      if (!save.ok) throw new Error("Could not save media record");
      updateQueued(q.key, { status: "done", progress: "Live on homepage" });
      return true;
    } catch (err) {
      updateQueued(q.key, { status: "error", error: err instanceof Error ? err.message : "Publish failed" });
      return false;
    }
  };

  const publishAll = async () => {
    const ready = queue.filter((q) => q.status === "ready" || q.status === "error");
    if (ready.length === 0 || publishing) return;
    setPublishing(true);
    setSuccess("");
    setPageError("");
    const startOrder = media.length > 0 ? Math.max(...media.map((m) => m.display_order ?? 0)) : 0;
    let done = 0;
    for (let i = 0; i < ready.length; i++) {
      const ok = await uploadOne(ready[i], startOrder + i + 1);
      if (ok) done++;
    }
    const res = await fetch("/api/homepage-media");
    if (res.ok) setMedia(await res.json());
    setQueue((prev) => prev.filter((q) => q.status !== "done"));
    if (done === ready.length) setSuccess(`${done} file${done === 1 ? "" : "s"} published to the homepage.`);
    else if (done > 0) setSuccess(`${done} of ${ready.length} files published. Others need attention below.`);
    else setPageError("Upload failed. Please check the files and try again.");
    setPublishing(false);
  };

  const toggleActive = async (item: MediaItem) => {
    setBusyId(item.id);
    try {
      await fetch("/api/homepage-media", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: item.id, active: !item.active }) });
      setMedia((prev) => prev.map((m) => (m.id === item.id ? { ...m, active: !m.active } : m)));
    } finally { setBusyId(null); }
  };
  const saveMedia = async (item: MediaItem) => {
    const edit = edits[item.id];
    if (!edit) return;
    setBusyId(item.id);
    try {
      const res = await fetch("/api/homepage-media", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: item.id, title: edit.title, description: edit.description, display_order: edit.display_order }) });
      if (res.ok) {
        const updated = (await res.json()) as MediaItem;
        setMedia((prev) => prev.map((m) => (m.id === item.id ? updated : m)));
        setEdits((prev) => { const next = { ...prev }; delete next[item.id]; return next; });
        setSuccess("Media updated.");
      }
    } finally { setBusyId(null); }
  };
  const moveMedia = async (item: MediaItem, dir: -1 | 1) => {
    const sorted = [...media].sort((a, b) => (a.display_order ?? 0) - (b.display_order ?? 0));
    const idx = sorted.findIndex((m) => m.id === item.id);
    const other = sorted[idx + dir];
    if (!other) return;
    try {
      await Promise.all([
        fetch("/api/homepage-media", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: item.id, display_order: other.display_order }) }),
        fetch("/api/homepage-media", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: other.id, display_order: item.display_order }) }),
      ]);
      const res = await fetch("/api/homepage-media");
      if (res.ok) setMedia(await res.json());
    } catch { /* noop */ }
  };
  const makeHero = async (item: MediaItem) => {
    const min = media.length > 0 ? Math.min(...media.map((m) => m.display_order ?? 0)) : 0;
    setBusyId(item.id);
    try {
      const res = await fetch("/api/homepage-media", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: item.id, display_order: min - 1, active: true }) });
      if (res.ok) {
        const all = await (await fetch("/api/homepage-media")).json();
        setMedia(Array.isArray(all) ? all : []);
        setSuccess(`"${item.title}" is now the hero feature.`);
      }
    } finally { setBusyId(null); }
  };
  const deleteMedia = async (item: MediaItem) => {
    if (!window.confirm(`Delete "${item.title || item.file_name}" from the homepage? This removes the file permanently.`)) return;
    setDeletingId(item.id);
    try {
      const res = await fetch(`/api/homepage-media?id=${item.id}`, { method: "DELETE" });
      if (res.ok) { setMedia((prev) => prev.filter((m) => m.id !== item.id)); setSuccess("Media deleted."); }
      else { setPageError("Delete failed. Please try again."); }
    } finally { setDeletingId(null); }
  };
  const onDrop = (e: DragEvent<HTMLDivElement>) => { e.preventDefault(); setDragging(false); if (e.dataTransfer.files) addFiles(e.dataTransfer.files); };
  const onFileInput = (e: ChangeEvent<HTMLInputElement>) => { if (e.target.files) addFiles(e.target.files); e.target.value = ""; };

  if (loading || dataLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-royal">
        <p className="font-italiana text-2xl text-gradient-gold tracking-[0.3em]">LOADING</p>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="bg-royal min-h-screen flex items-center justify-center px-6 pt-20">
        <div className="max-w-xl w-full text-center bg-card p-12 border-gold-soft border">
          <Lock size={36} className="text-gold mx-auto mb-6 opacity-40" />
          <div className="ornament-line mb-2 justify-center"><Ornament>Restricted Access</Ornament></div>
          <h1 className="font-display text-4xl text-cream mb-3">The Prestige Chambers are Locked</h1>
          <p className="text-cream-dim font-light mb-8">This area is reserved for authorized personnel. Please sign in with the appropriate credentials.</p>
          <Link to="/login" className="btn-primary">Sign In</Link>
        </div>
      </div>
    );
  }

  const today = new Date().toISOString().slice(0, 10);
  const upcoming = appointments.filter((a) => a.date >= today && a.status !== "cancelled");
  const stats = [
    { label: "Upcoming Appointments", value: upcoming.length },
    { label: "Pending Reservations", value: appointments.filter((a) => a.status === "pending").length },
    { label: "Open Conversations", value: conversations.filter((c) => c.status === "open").length },
    { label: "New Inquiries", value: inquiries.filter((i) => i.status === "new").length },
    { label: "Open Tickets", value: tickets.filter((t) => t.status === "open").length },
    { label: "Homepage Media", value: media.length },
  ];
  const activeInquiry = inquiries.find((i) => i.id === selectedInquiry) || null;
  const activeTicket = tickets.find((t) => t.id === selectedTicket) || null;
  const sortedMedia = [...media].sort((a, b) => (a.display_order ?? 0) - (b.display_order ?? 0));
  const heroId = sortedMedia.find((m) => m.active)?.id;

  const apptCard = (a: Appointment, dim: boolean) => (
    <div key={a.id} className={`bg-card p-5 border-gold-soft border ${dim ? "opacity-80" : ""}`}>
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="min-w-0">
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            <span className="font-display text-lg text-cream">{a.service_name}</span>
            {a.status && (<span className={`text-[10px] tracking-[0.2em] uppercase px-2 py-0.5 border ${statusClasses(a.status)}`}>{a.status}</span>)}
          </div>
          <p className="text-cream text-sm truncate">{a.name} \u00b7 {formatDate(a.date)} \u00b7 {a.time}</p>
          <p className="text-xs text-cream-dim truncate">{a.email} {a.phone ? `\u00b7 ${a.phone}` : ""}</p>
          {!dim && a.notes && <p className="text-xs text-cream-dim italic mt-1">{a.notes}</p>}
        </div>
        <div className="flex items-center gap-2">
          <select value={a.status || "pending"} onChange={(e) => setAppointmentStatus(a.id, e.target.value)} className="input-royal text-xs" style={selectStyle}>
            {appointmentStatuses.map((s) => (<option key={s} value={s}>{s}</option>))}
          </select>
          <button onClick={() => deleteAppointment(a.id)} className="p-2 text-cream-dim hover:text-danger transition-colors" aria-label="Delete"><Trash2 size={16} /></button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="bg-royal pt-24 pb-12 px-4 sm:px-6 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8 flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="ornament-line mb-2 justify-center"><Ornament>Concierge Dashboard</Ornament></div>
            <h1 className="font-display text-4xl text-cream">Charlotte Prestige Administration</h1>
            <p className="text-cream-dim text-sm mt-1">Welcome back, {profile?.display_name || "Concierge"}.</p>
          </div>
        </motion.div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
          {stats.map((s) => (
            <div key={s.label} className="bg-card p-6 border-gold-soft border text-center">
              <p className="font-italiana text-4xl text-gradient-gold">{s.value}</p>
              <p className="text-[10px] tracking-[0.2em] uppercase text-cream-dim mt-2">{s.label}</p>
            </div>
          ))}
        </div>
        <div className="flex gap-1 mb-6 overflow-x-auto pb-2 border-b border-gold-soft">
          {tabs.map((t) => (
            <button key={t.key} onClick={() => setActiveTab(t.key)} className={`flex items-center gap-2 px-4 py-3 text-xs tracking-[0.15em] uppercase whitespace-nowrap border-b-2 -mb-2.5 transition-colors ${activeTab === t.key ? "text-gold border-gold" : "text-cream-dim border-transparent hover:text-cream"}`}>
              <t.icon size={15} /> {t.label}
            </button>
          ))}
        </div>

        {activeTab === "appointments" && (
          <div>
            <h2 className="font-display text-2xl text-cream mb-5">Upcoming Appointments</h2>
            {upcoming.length === 0 ? (<p className="text-center text-cream-dim text-sm py-6">No upcoming appointments</p>) : (<div className="space-y-3 mb-10">{upcoming.map((a) => apptCard(a, false))}</div>)}
            <h2 className="font-display text-2xl text-cream mb-5">All Reservations</h2>
            {appointments.length === 0 ? (<p className="text-center text-cream-dim text-sm py-6">No appointments found.</p>) : (<div className="space-y-3">{appointments.map((a) => apptCard(a, true))}</div>)}
          </div>
        )}

        {activeTab === "media" && (
          <div>
            <div className="flex flex-wrap items-end justify-between gap-3 mb-5">
              <div>
                <h2 className="font-display text-2xl text-cream">Homepage Media</h2>
                <p className="text-sm text-cream-dim font-light mt-1">Upload images and videos for the homepage hero and gallery. The lowest-order visible item becomes the hero feature.</p>
              </div>
              <Link to="/" className="btn-secondary text-xs py-2.5 px-4 flex items-center gap-2"><ExternalLink size={14} /> View Homepage</Link>
            </div>
            <div>
              <div onClick={() => fileInput.current?.click()} onDragOver={(e) => { e.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={onDrop} className={`border border-dashed p-10 text-center cursor-pointer transition-all mb-6 ${dragging ? "border-gold bg-gold-soft" : "border-gold-soft hover:border-gold"}`}>
                <Upload size={30} className="text-gold mx-auto mb-4" />
                <p className="font-display text-xl text-cream mb-1">Drop images or videos here, or click to browse</p>
                <p className="text-xs text-cream-dim font-light">All image &amp; video formats accepted \u2014 JPG, PNG, GIF, WebP, SVG, HEIC, AVIF, TIFF, BMP \u00b7 MP4, WebM, MOV, AVI, MKV, and more \u00b7 Up to 500MB per file</p>
                <input ref={fileInput} type="file" accept="image/*,video/*" multiple onChange={onFileInput} className="hidden" />
              </div>
              {queue.length > 0 && (
                <div className="bg-card border-gold-soft border p-5 mb-6">
                  <div className="flex items-center justify-between mb-4">
                    <p className="text-sm text-cream font-medium">Ready to publish ({queue.filter((q) => q.status !== "done").length})</p>
                    <div className="flex gap-2">
                      <button onClick={() => { queue.forEach((q) => URL.revokeObjectURL(q.previewUrl)); setQueue([]); }} className="text-xs text-cream-dim hover:text-cream px-3 py-2">Clear all</button>
                      <button onClick={publishAll} disabled={publishing} className="btn-primary text-xs py-2.5 px-5 disabled:opacity-40">
                        {publishing ? (<><Loader2 size={14} className="animate-spin" /> Publishing...</>) : (<><Upload size={14} /> Publish to Homepage</>)}
                      </button>
                    </div>
                  </div>
                  <div className="space-y-3">
                    {queue.map((q) => (
                      <div key={q.key} className="flex flex-col md:flex-row gap-4 p-4 border border-gold-soft bg-[#0a090866]">
                        <div className="w-full md:w-44 h-28 flex-shrink-0 overflow-hidden border border-gold-soft bg-black relative">
                          {q.mediaType === "video" ? (<video src={q.previewUrl} muted playsInline preload="metadata" className="w-full h-full object-cover" />) : (<img src={q.previewUrl} alt="" className="w-full h-full object-cover" />)}
                          <span className="absolute bottom-1 left-1 text-[9px] tracking-widest uppercase px-1.5 py-0.5 flex items-center gap-1 bg-[#0a0908cc] text-gold">{q.mediaType === "video" ? <Film size={10} /> : <ImageIcon size={10} />} {q.mediaType}</span>
                        </div>
                        <div className="flex-1 min-w-0 space-y-2">
                          <div className="flex items-start justify-between gap-3">
                            <div className="min-w-0">
                              <p className="text-sm text-cream truncate">{q.file.name}</p>
                              <p className="text-xs text-cream-dim">{formatFileSize(q.file.size)}</p>
                            </div>
                            <button onClick={() => removeQueued(q.key)} className="p-1 text-cream-dim hover:text-danger transition-colors" aria-label="Remove"><X size={16} /></button>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                            <input value={q.title} onChange={(e) => updateQueued(q.key, { title: e.target.value })} placeholder="Title" className="input-royal text-sm" />
                            <input value={q.description} onChange={(e) => updateQueued(q.key, { description: e.target.value })} placeholder="Description (optional)" className="input-royal text-sm" />
                          </div>
                          {q.status === "uploading" && (<p className="text-xs text-gold flex items-center gap-2"><span className="w-3 h-3 border border-gold border-t-transparent rounded-full animate-spin inline-block" />{q.progress}</p>)}
                          {q.status === "done" && (<p className="text-xs text-success flex items-center gap-1"><Check size={13} /> {q.progress}</p>)}
                          {q.status === "error" && <p className="text-xs text-danger">{q.error}</p>}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
            {success && <p className="text-sm text-success mb-4">{success}</p>}
            {pageError && <p className="text-sm text-danger mb-4">{pageError}</p>}
            <h3 className="font-display text-xl text-cream mb-4">Currently on the Homepage ({sortedMedia.length})</h3>
            {sortedMedia.length === 0 ? (
              <div className="bg-card p-12 border-gold-soft border text-center">
                <ImageIcon size={30} className="text-gold mx-auto mb-3 opacity-50" />
                <p className="text-cream-dim text-sm font-light">No homepage media yet. Upload your first image or video above.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                {sortedMedia.map((m) => {
                  const edit = edits[m.id];
                  const title = edit?.title ?? m.title ?? "";
                  const desc = edit?.description ?? m.description ?? "";
                  const order = edit?.display_order ?? m.display_order ?? 0;
                  const setEdit = (patch: Partial<{ title: string; description: string; display_order: number }>) =>
                    setEdits((prev) => ({ ...prev, [m.id]: { title: patch.title ?? prev[m.id]?.title ?? m.title ?? "", description: patch.description ?? prev[m.id]?.description ?? m.description ?? "", display_order: patch.display_order ?? prev[m.id]?.display_order ?? m.display_order ?? 0 } }));
                  return (
                    <div key={m.id} className="bg-card border-gold-soft border overflow-hidden">
                      <div className="aspect-video relative bg-black overflow-hidden">
                        {m.media_type === "video" ? (<video src={m.file_url} muted playsInline preload="metadata" className="w-full h-full object-cover" />) : (<img src={m.file_url} alt={m.title || ""} loading="lazy" className="w-full h-full object-cover" />)}
                        <span className="absolute top-2 left-2 text-[9px] tracking-widest uppercase px-2 py-1 flex items-center gap-1 border border-gold text-gold bg-[#0a0908cc]">{m.media_type === "video" ? <Film size={10} /> : <ImageIcon size={10} />} {m.media_type}</span>
                        {!m.active && (<span className="absolute top-2 right-2 text-[9px] tracking-widest uppercase px-2 py-1 flex items-center gap-1 bg-[#0a0908cc] text-cream-dim border border-gold-soft"><EyeOff size={10} /> Hidden</span>)}
                        {m.id === heroId && (
                          <span className="absolute inset-0 flex items-center justify-center pointer-events-none">
                            <span className="text-[10px] tracking-[0.25em] uppercase text-cream-dim border border-gold-soft px-3 py-1.5 flex items-center gap-1 bg-[#0a0908cc]"><Star size={11} className="text-gold" /> Hero Feature</span>
                          </span>
                        )}
                      </div>
                      <div className="p-4 space-y-2">
                        <input value={title} onChange={(e) => setEdit({ title: e.target.value })} placeholder="Title" className="input-royal text-sm" />
                        <input value={desc} onChange={(e) => setEdit({ description: e.target.value })} placeholder="Description" className="input-royal text-sm" />
                        <div className="flex items-center gap-2 text-xs text-cream-dim">
                          <span className="truncate flex-1">{m.file_name}</span>
                          <span className="flex items-center gap-1 flex-shrink-0">
                            <span className="text-[10px] uppercase tracking-wider">Order</span>
                            <input type="number" value={order} onChange={(e) => setEdit({ display_order: Number(e.target.value) })} className="input-royal text-xs" style={{ width: "64px", padding: "0.4rem 0.5rem" }} />
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5 pt-1 flex-wrap">
                          <button onClick={() => moveMedia(m, -1)} title="Move up" className="p-2 border border-gold-soft text-cream-dim hover:text-gold hover:border-gold transition-colors"><ChevronUp size={15} /></button>
                          <button onClick={() => moveMedia(m, 1)} title="Move down" className="p-2 border border-gold-soft text-cream-dim hover:text-gold hover:border-gold transition-colors"><ChevronDown size={15} /></button>
                          <button onClick={() => makeHero(m)} title="Set as hero" className="p-2 border border-gold-soft text-cream-dim hover:text-gold hover:border-gold transition-colors"><Star size={15} /></button>
                          <button onClick={() => toggleActive(m)} title={m.active ? "Hide" : "Show"} className="p-2 border border-gold-soft text-cream-dim hover:text-gold hover:border-gold transition-colors">{m.active ? <Eye size={15} /> : <EyeOff size={15} />}</button>
                          <button onClick={() => saveMedia(m)} disabled={!edit || busyId === m.id} className="flex-1 px-3 py-2 text-xs btn-primary disabled:opacity-40" style={{ padding: "0.5rem 0.75rem" }}>{busyId === m.id ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />}</button>
                          <button onClick={() => deleteMedia(m)} disabled={deletingId === m.id} className="p-2 text-cream-dim hover:text-danger transition-colors disabled:opacity-40" aria-label="Delete">{deletingId === m.id ? <Loader2 size={15} className="animate-spin" /> : <Trash2 size={15} />}</button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {activeTab === "conversations" && (
          <div>
            <h2 className="font-display text-2xl text-cream mb-5">Charlotte Prestige Concierge</h2>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              <div className="bg-card border-gold-soft border overflow-hidden">
                <div className="p-4 border-b border-gold-soft"><p className="label-royal">Recent Conversations</p></div>
                <div className="overflow-y-auto" style={{ maxHeight: "480px" }}>
                  {conversations.length === 0 ? (
                    <p className="p-8 text-center text-cream-dim text-sm">No conversations yet</p>
                  ) : (conversations.map((c) => (
                    <button key={c.id} onClick={() => setSelectedConvo(c.id)} className={`w-full text-left p-4 border-b border-gold-soft transition-colors ${selectedConvo === c.id ? "bg-gold-soft" : "hover:bg-gold-soft/50"}`}>
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <span className="text-cream text-sm font-medium truncate">{c.name || "Guest"}</span>
                        {c.status && (<span className={`text-[9px] tracking-widest uppercase px-1.5 py-0.5 border flex-shrink-0 ${statusClasses(c.status)}`}>{c.status}</span>)}
                      </div>
                      <p className="text-xs text-cream-dim mb-2 truncate">{c.email}</p>
                      <p className="text-xs text-cream-dim flex gap-4"><span>{c.subject || "Concierge Chat"}</span></p>
                    </button>
                  )))}
                </div>
              </div>
              <div className="lg:col-span-2 bg-card border-gold-soft border flex flex-col" style={{ minHeight: "480px" }}>
                {selectedConvo ? (
                  <>
                    <div className="p-5 border-b border-gold-soft flex items-center gap-3 overflow-x-auto">
                      <span className="text-cream text-sm font-medium">Conversation</span>
                      <select value={conversations.find((c) => c.id === selectedConvo)?.status || "open"} onChange={(e) => setConvoStatus(selectedConvo, e.target.value)} className="input-royal text-xs" style={selectStyle}>
                        {conversationStatuses.map((s) => (<option key={s} value={s}>{s}</option>))}
                      </select>
                    </div>
                    <div className="flex-1 overflow-y-auto p-5 space-y-3" style={{ maxHeight: "380px" }}>
                      {messages.length === 0 ? (
                        <p className="text-center text-cream-dim text-sm py-10">No messages yet.</p>
                      ) : (messages.map((m) => (
                        <div key={m.id} className={m.sender === "concierge" ? "text-right" : "text-left"}>
                          <div className={`inline-block max-w-[80%] p-3 text-sm border ${m.sender === "concierge" ? "border-gold bg-gold-soft text-cream" : "border-gold-soft text-cream-dim"}`}>
                            <p className="text-[10px] tracking-wider uppercase mb-1 text-gold">{m.sender_name}</p>
                            <p className="font-light leading-relaxed">{m.body}</p>
                          </div>
                        </div>
                      )))}
                    </div>
                    <form onSubmit={sendReply} className="p-4 border-t border-gold-soft flex gap-2">
                      <input value={reply} onChange={(e) => setReply(e.target.value)} placeholder="Write a reply..." className="input-royal" />
                      <button type="submit" disabled={replying || !reply.trim()} className="btn-primary text-xs disabled:opacity-40 flex-shrink-0">
                        {replying ? <Loader2 size={14} className="animate-spin" /> : <Send size={14} />}
                      </button>
                    </form>
                  </>
                ) : (
                  <div className="flex-1 flex flex-col items-center justify-center text-cream-dim">
                    <MessageCircle size={32} className="mb-3 opacity-40" />
                    <p className="text-sm">Select a conversation to begin</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {activeTab === "inquiries" && (
          <div>
            <h2 className="font-display text-2xl text-cream mb-5">Contact Inquiries</h2>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              <div className="space-y-3">
                {inquiries.length === 0 ? (
                  <p className="bg-card p-8 border-gold-soft border text-center text-cream-dim text-sm">No inquiries yet</p>
                ) : (inquiries.map((i) => (
                  <button key={i.id} onClick={() => { setSelectedInquiry(i.id); setInquiryResponse(i.response || ""); }} className={`w-full text-left bg-card p-5 border-gold-soft border hover:border-gold transition-all ${selectedInquiry === i.id ? "border-gold" : ""}`}>
                    <div className="flex items-start justify-between mb-5 gap-2">
                      <span className="text-cream text-sm font-medium truncate">{i.name}</span>
                      {i.status && (<span className={`text-[9px] tracking-widest uppercase px-1.5 py-0.5 border flex-shrink-0 ${statusClasses(i.status)}`}>{i.status}</span>)}
                    </div>
                    <p className="text-sm text-cream-dim mt-1 truncate">{i.subject}</p>
                    <p className="text-xs text-cream-dim mt-3 line-clamp-2">{i.message}</p>
                  </button>
                )))}
              </div>
              <div className="lg:col-span-2">
                {activeInquiry ? (
                  <div className="bg-card p-6 border-gold-soft border">
                    <div className="flex items-start justify-between gap-3 mb-4">
                      <div>
                        <h3 className="font-display text-xl text-cream">{activeInquiry.subject}</h3>
                        <p className="text-xs text-cream-dim mt-1">{activeInquiry.name} \u00b7 {activeInquiry.email}</p>
                      </div>
                      <select value={activeInquiry.status || "new"} onChange={(e) => setInquiryStatus(activeInquiry.id, e.target.value)} className="input-royal text-xs" style={selectStyle}>
                        {inquiryStatuses.map((s) => (<option key={s} value={s}>{s}</option>))}
                      </select>
                    </div>
                    <p className="text-sm text-cream font-light leading-relaxed p-4 mb-4 bg-[#0a090866] border border-gold-soft">{activeInquiry.message}</p>
                    <label className="label-royal">Concierge Response</label>
                    <textarea value={inquiryResponse} onChange={(e) => setInquiryResponse(e.target.value)} placeholder="Write your response..." rows={4} className="input-royal resize-none mb-3" />
                    <button onClick={respondInquiry} disabled={!inquiryResponse.trim()} className="btn-primary text-xs disabled:opacity-40"><Send size={14} /> Send Response</button>
                  </div>
                ) : (
                  <div className="bg-card p-12 border-gold-soft border text-center text-cream-dim text-sm h-full flex items-center justify-center">Select an inquiry to view and respond</div>
                )}
              </div>
            </div>
          </div>
        )}

        {activeTab === "tickets" && (
          <div>
            <h2 className="font-display text-2xl text-cream mb-5">Support Tickets</h2>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              <div className="space-y-3">
                {tickets.length === 0 ? (
                  <p className="bg-card p-8 border-gold-soft border text-center text-cream-dim text-sm">No tickets yet</p>
                ) : (tickets.map((t) => (
                  <button key={t.id} onClick={() => { setSelectedTicket(t.id); setTicketResponse(t.response || ""); }} className={`w-full text-left bg-card p-5 border-gold-soft border hover:border-gold transition-all ${selectedTicket === t.id ? "border-gold" : ""}`}>
                    <div className="flex items-start justify-between mb-5 gap-2">
                      <span className="text-cream text-sm font-medium truncate">{t.subject || "Support Request"}</span>
                      {t.status && (<span className={`text-[9px] tracking-widest uppercase px-1.5 py-0.5 border flex-shrink-0 ${statusClasses(t.status)}`}>{t.status}</span>)}
                    </div>
                    <p className="text-sm text-cream-dim mt-1 truncate">{t.name}</p>
                    <div className="grid grid-cols-3 gap-3 mb-4 mt-3">
                      <span className="text-xs text-cream-dim">{t.category}</span>
                      <span className="text-xs text-cream-dim">{t.priority}</span>
                      <span className="text-xs text-cream-dim truncate">{t.email}</span>
                    </div>
                    <p className="text-xs text-cream-dim line-clamp-2">{t.message}</p>
                  </button>
                )))}
              </div>
              <div className="lg:col-span-2">
                {activeTicket ? (
                  <div className="bg-card p-6 border-gold-soft border">
                    <div className="flex items-start justify-between gap-3 mb-4">
                      <div>
                        <h3 className="font-display text-xl text-cream">{activeTicket.subject || "Support Request"}</h3>
                        <p className="text-xs text-cream-dim mt-1">{activeTicket.name} \u00b7 {activeTicket.email} \u00b7 {activeTicket.category} \u00b7 {activeTicket.priority}</p>
                      </div>
                      <select value={activeTicket.status || "open"} onChange={(e) => setTicketStatus(activeTicket.id, e.target.value)} className="input-royal text-xs" style={selectStyle}>
                        {ticketStatuses.map((s) => (<option key={s} value={s}>{s}</option>))}
                      </select>
                    </div>
                    <p className="text-sm text-cream font-light leading-relaxed p-4 mb-4 bg-[#0a090866] border border-gold-soft">{activeTicket.message}</p>
                    <label className="label-royal">Concierge Response</label>
                    <textarea value={ticketResponse} onChange={(e) => setTicketResponse(e.target.value)} placeholder="Write your response..." rows={4} className="input-royal resize-none mb-3" />
                    <button onClick={respondTicket} disabled={!ticketResponse.trim()} className="btn-primary text-xs disabled:opacity-40"><Send size={14} /> Send Response</button>
                  </div>
                ) : (
                  <div className="bg-card p-12 border-gold-soft border text-center text-cream-dim text-sm h-full flex items-center justify-center">Select a ticket to view and respond</div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
