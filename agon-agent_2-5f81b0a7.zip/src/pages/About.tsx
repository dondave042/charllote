import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { BadgeCheck, Gem, Globe, MessageCircle, ShieldCheck, Sparkles } from "lucide-react";
import Ornament from "../components/Ornament";

const pillars = [
  { icon: ShieldCheck, title: "Discretion", text: "Every conversation is held in strictest confidence. Our members' identities are never disclosed, never recorded, never shared." },
  { icon: Sparkles, title: "Attention to Detail", text: "From the cut of a suit to the choice of vintage, every detail is considered. We attend to the things you would never think to ask for." },
  { icon: MessageCircle, title: "Conversation", text: "Our companions are present, attentive, and authentically engaged. The art of conversation is the foundation of everything we offer." },
  { icon: BadgeCheck, title: "Vetting", text: "Only the most exceptional individuals join the Charlotte Prestige family. Each companion is interviewed, vetted, and trained to our exacting standards." },
  { icon: Gem, title: "Bespoke", text: "No two members are the same, and no two experiences should be. Every encounter is composed uniquely for you." },
  { icon: Globe, title: "Global Reach", text: "From Manhattan to Mykonos, London to Dubai \u2014 wherever your travels take you, a Charlotte Prestige companion can be arranged." },
];

const stats = [
  { value: "12", label: "Years of Distinction" },
  { value: "2.4K", label: "Distinguished Members" },
  { value: "18", label: "Cities Served" },
  { value: "24/7", label: "Concierge At Hand" },
];

export default function About() {
  return (
    <div className="bg-royal pt-32 pb-20 min-h-screen">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }} className="max-w-5xl mx-auto text-center mb-16">
          <div className="ornament-line mb-6 justify-center"><Ornament>Our Story \u00b7 Since MMXX</Ornament></div>
          <h1 className="font-display text-5xl sm:text-7xl text-cream mb-6">A House Built on Trust</h1>
          <p className="font-display italic text-xl text-cream-dim max-w-2xl mx-auto">A decade devoted to the craft of refined companionship.</p>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-60px" }} transition={{ duration: 0.7 }} className="relative overflow-hidden border border-gold-soft mb-16">
          <div className="aspect-[16/7]">
            <img src="/images/about.jpg" alt="The House" className="w-full h-full object-cover opacity-60" />
          </div>
          <div className="absolute inset-0 hero-overlay" />
          <div className="absolute inset-0 flex items-center justify-center">
            <p className="font-italiana text-gradient-gold text-2xl sm:text-4xl tracking-[0.2em] text-center px-6">THE ART OF COMPANIONSHIP</p>
          </div>
        </motion.div>
        <div className="max-w-3xl mx-auto space-y-8 mb-20">
          <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-60px" }} transition={{ duration: 0.7 }}>
            <h2 className="font-display text-4xl text-cream mb-6">Our Philosophy</h2>
            <p className="text-cream-dim leading-relaxed font-light mb-4">Charlotte Prestige was founded on a simple but uncompromising idea: that companionship, at its highest expression, is an art form. Not a transaction, but a craft \u2014 one that demands refinement, empathy, and an unwavering commitment to the person before us.</p>
            <p className="text-cream-dim leading-relaxed font-light">From a single salon in Manhattan, we have grown into a trusted house serving distinguished members across three continents. Yet our philosophy has never wavered: every encounter is bespoke, every detail considered, every confidence kept.</p>
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-60px" }} transition={{ duration: 0.7 }}>
            <h2 className="font-display text-4xl text-cream mb-6">Our Vows</h2>
            <p className="text-cream-dim leading-relaxed font-light mb-4">We believe that true luxury lies in the considered gesture, the unhurried moment, the conversation that lingers. Our companions are chosen for their depth as much as their beauty \u2014 well-traveled, well-read, fluent in the languages of culture, cuisine, and quiet charm.</p>
            <p className="text-cream-dim leading-relaxed font-light">Every arrangement begins with a conversation. We listen \u2014 to your preferences, your mood, the unspoken detail \u2014 and compose an experience that feels inevitable, as if it could not have unfolded any other way.</p>
          </motion.div>
        </div>
        <div className="text-center mb-12">
          <div className="ornament-line mb-6 justify-center"><Ornament>The Pillars of Charlotte Prestige</Ornament></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-20">
          {pillars.map((p, i) => (
            <motion.div key={p.title} initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-60px" }} transition={{ duration: 0.6, delay: (i % 3) * 0.1 }} className="bg-card p-7 hover:bg-card-hover transition-all duration-500">
              <p.icon size={26} className="text-gold mb-5" />
              <h3 className="font-display text-xl text-cream mb-3">{p.title}</h3>
              <p className="text-sm text-cream-dim font-light leading-relaxed">{p.text}</p>
            </motion.div>
          ))}
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center mb-20">
          {stats.map((s) => (
            <div key={s.label}>
              <p className="font-italiana text-5xl text-gradient-gold mb-2">{s.value}</p>
              <p className="text-xs text-cream-dim tracking-wider uppercase">{s.label}</p>
            </div>
          ))}
        </div>
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="font-display text-4xl sm:text-6xl text-cream mb-6">Your story awaits.</h2>
          <p className="text-cream-dim max-w-xl mx-auto mb-10 font-light leading-relaxed">A conversation is all it takes. Our concierge stands ready, day or night, to begin curating something unforgettable.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/services" className="btn-secondary">Explore Experiences</Link>
            <Link to="/booking" className="btn-primary">Book an Experience</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
