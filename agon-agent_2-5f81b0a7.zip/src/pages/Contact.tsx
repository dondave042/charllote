import { useEffect, useState } from "react";
import type { FormEvent } from "react";
import { motion } from "framer-motion";
import { CheckCircle, Clock, Loader2, Mail, MessageCircle, Phone, Send } from "lucide-react";
import Ornament from "../components/Ornament";
import { useAuth } from "../contexts/AuthContext";
import { openLiveChat } from "../lib/format";

const subjects = ["General Inquiry", "Reservations", "Membership", "Events", "Other"];

export default function Contact() {
  const { user, profile } = useAuth();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [subject, setSubject] = useState(subjects[0]);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  useEffect(() => {
    if (user?.email) setEmail((v) => v || user.email || "");
    if (profile?.display_name) setName((v) => v || profile.display_name || "");
  }, [user, profile]);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !message.trim()) { setError("Please complete your name, email, and message."); return; }
    setError("");
    setSending(true);
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name.trim(), email: email.trim(), subject, message: message.trim() }),
      });
      if (!res.ok) throw new Error("send failed");
      setSent(true);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch {
      setError("Failed to send. Please try again.");
    } finally {
      setSending(false);
    }
  };

  const reset = () => { setSent(false); setName(""); setEmail(""); setSubject(subjects[0]); setMessage(""); };

  return (
    <div className="bg-royal pt-32 pb-20 min-h-screen">
      <div className="px-6 pb-12 relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <img src="/images/contact-bg.jpg" alt="" className="w-full h-full object-cover" />
        </div>
        <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }} className="relative max-w-5xl mx-auto text-center">
          <div className="ornament-line mb-6 justify-center"><Ornament>Concierge</Ornament></div>
          <h1 className="font-display text-5xl sm:text-7xl text-cream mb-4">Begin the Conversation</h1>
          <p className="text-cream-dim font-light max-w-xl mx-auto">Our concierge stands ready to receive your inquiry, day or night.</p>
        </motion.div>
      </div>
      <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-5 gap-8 px-6">
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-card p-7 border-gold-soft border">
            <h2 className="font-display text-2xl text-cream mb-5">Direct Channels</h2>
            <div className="space-y-5">
              <div className="flex gap-4">
                <Phone size={18} className="text-gold flex-shrink-0 mt-0.5" />
                <div>
                  <p className="label-royal">Concierge Line</p>
                  <a href="tel:+18885550192" className="text-cream hover:text-gold transition-colors">+1 (888) 555-0192 \u00b7 24/7</a>
                </div>
              </div>
              <div className="flex gap-4">
                <Mail size={18} className="text-gold flex-shrink-0 mt-0.5" />
                <div>
                  <p className="label-royal">Email</p>
                  <a href="mailto:concierge@charlotteprestige.com" className="text-cream hover:text-gold transition-colors text-sm leading-relaxed break-all">concierge@charlotteprestige.com</a>
                </div>
              </div>
              <div className="flex gap-4">
                <Clock size={18} className="text-gold flex-shrink-0 mt-0.5" />
                <div>
                  <p className="label-royal">Hours</p>
                  <p className="text-cream text-sm leading-relaxed">Concierge always available \u2014 day &amp; night, every day.</p>
                </div>
              </div>
            </div>
          </div>
          <div className="bg-card p-7 border-gold-soft border">
            <div className="flex items-center gap-3 mb-3">
              <MessageCircle size={20} className="text-gold" />
              <h3 className="font-display text-xl text-cream">Prefer to chat?</h3>
            </div>
            <p className="text-sm text-cream-dim font-light leading-relaxed mb-3">For the swiftest reply, click the concierge button in the corner of your screen. Our team is online and ready to assist you discreetly.</p>
            <button onClick={openLiveChat} className="btn-secondary w-full text-xs">Open Live Chat</button>
          </div>
        </div>
        <div className="lg:col-span-3">
          {sent ? (
            <div className="bg-card p-8 border-gold-soft border text-center h-full flex flex-col items-center justify-center py-16">
              <div className="w-16 h-16 mx-auto mb-6 rounded-full flex items-center justify-center border border-gold"><CheckCircle size={28} className="text-gold" /></div>
              <h2 className="font-display text-3xl text-cream mb-3">Message Received</h2>
              <p className="text-cream-dim font-light mb-5">Our concierge will be in touch shortly.</p>
              <button onClick={reset} className="btn-secondary text-xs">Send Another</button>
            </div>
          ) : (
            <form onSubmit={submit} className="bg-card p-8 border-gold-soft border">
              <h2 className="font-display text-2xl text-cream mb-5">Write to Us</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-5">
                <div>
                  <label className="label-royal">Your Name</label>
                  <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Your full name" className="input-royal" />
                </div>
                <div>
                  <label className="label-royal">Email</label>
                  <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" className="input-royal" />
                </div>
              </div>
              <div className="mb-5">
                <label className="label-royal">Subject</label>
                <select value={subject} onChange={(e) => setSubject(e.target.value)} className="input-royal">
                  {subjects.map((s) => (<option key={s} value={s}>{s}</option>))}
                </select>
              </div>
              <div className="mb-5">
                <label className="label-royal">Your Message</label>
                <textarea value={message} onChange={(e) => setMessage(e.target.value)} placeholder="How may our concierge assist you?" rows={6} className="input-royal resize-none" />
              </div>
              {error && <p className="text-sm text-danger mb-5">{error}</p>}
              <button type="submit" disabled={sending} className="btn-primary w-full md:w-auto">
                {sending ? (<><Loader2 size={16} className="animate-spin" /> Sending...</>) : (<><Send size={15} /> Send Message</>)}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
