import { useEffect, useState } from "react";
import type { FormEvent } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight, Calendar, Check, Clock, FileText, Heart, Loader2, Phone, Ticket, User, X } from "lucide-react";
import Ornament from "../components/Ornament";
import { useAuth } from "../contexts/AuthContext";
import { formatDate, statusClasses } from "../lib/format";
import type { Appointment, SupportTicket } from "../lib/types";

export default function Profile() {
  const { user, profile, refreshProfile, signOut } = useAuth();
  const navigate = useNavigate();
  const [tab, setTab] = useState<"reservations" | "tickets">("reservations");
  const [reservations, setReservations] = useState<Appointment[]>([]);
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [loadingLists, setLoadingLists] = useState(true);
  const [displayName, setDisplayName] = useState("");
  const [phone, setPhone] = useState("");
  const [pronouns, setPronouns] = useState("");
  const [bio, setBio] = useState("");
  const [saving, setSaving] = useState(false);
  const [savedMsg, setSavedMsg] = useState("");
  const [cancelling, setCancelling] = useState<number | null>(null);

  useEffect(() => {
    setDisplayName(profile?.display_name || "");
    setPhone(profile?.phone || "");
    setPronouns(profile?.pronouns || "");
    setBio(profile?.bio || "");
  }, [profile]);

  useEffect(() => {
    if (!user?.email) return;
    setLoadingLists(true);
    const load = async () => {
      try {
        const [a, t] = await Promise.all([
          fetch(`/api/appointments?email=${encodeURIComponent(user.email || "")}`),
          fetch(`/api/support?email=${encodeURIComponent(user.email || "")}`),
        ]);
        if (a.ok) { const d = await a.json(); setReservations(Array.isArray(d) ? d : []); }
        if (t.ok) { const d = await t.json(); setTickets(Array.isArray(d) ? d : []); }
      } catch { /* noop */ } finally { setLoadingLists(false); }
    };
    load();
  }, [user]);

  const save = async (e: FormEvent) => {
    e.preventDefault();
    if (!user?.email) return;
    setSaving(true);
    setSavedMsg("");
    try {
      const res = await fetch("/api/profiles", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: user.email, display_name: displayName, phone, pronouns, bio }),
      });
      if (res.ok) { setSavedMsg("Your details have been saved."); refreshProfile(); }
      else { setSavedMsg("Failed to save. Please try again."); }
    } catch {
      setSavedMsg("Failed to save. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  const cancelReservation = async (appt: Appointment) => {
    setCancelling(appt.id);
    try {
      const res = await fetch("/api/appointments", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: appt.id, status: "cancelled" }),
      });
      if (res.ok && user?.email) {
        const r = await fetch(`/api/appointments?email=${encodeURIComponent(user.email)}`);
        if (r.ok) setReservations(await r.json());
      }
    } catch { /* noop */ } finally { setCancelling(null); }
  };

  const handleSignOut = async () => { await signOut(); navigate("/"); };
  const name = profile?.display_name || user?.email?.split("@")[0] || "Member";

  return (
    <div className="bg-royal pt-32 pb-20 px-6 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
          <div className="ornament-line mb-6 justify-center"><Ornament>My Account</Ornament></div>
          <h1 className="font-display text-5xl sm:text-6xl text-cream mb-4">Welcome, {name}</h1>
          <p className="text-cream-dim font-light">Your private corner of Charlotte Prestige.</p>
        </motion.div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="bg-card p-7 border-gold-soft border lg:sticky lg:top-24 self-start">
            <div className="flex items-center justify-between mb-5">
              <h2 className="font-display text-xl text-cream">Profile</h2>
              <User size={18} className="text-gold" />
            </div>
            <form onSubmit={save} className="space-y-4">
              <div>
                <label className="label-royal">Display name</label>
                <input value={displayName} onChange={(e) => setDisplayName(e.target.value)} className="input-royal" />
              </div>
              <div>
                <label className="label-royal">Email</label>
                <input value={user?.email || ""} disabled className="input-royal opacity-60" />
              </div>
              <div>
                <label className="label-royal flex items-center gap-1"><Phone size={12} /> Phone</label>
                <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+1 (555) 000-0000" className="input-royal" />
              </div>
              <div>
                <label className="label-royal">Pronouns</label>
                <input value={pronouns} onChange={(e) => setPronouns(e.target.value)} placeholder="e.g. she/her" className="input-royal" />
              </div>
              <div>
                <label className="label-royal flex items-center gap-1"><Heart size={12} /> Bio</label>
                <textarea value={bio} onChange={(e) => setBio(e.target.value)} placeholder="A few words about yourself..." rows={3} className="input-royal resize-none text-sm" />
              </div>
              {savedMsg && <p className="text-xs text-gold">{savedMsg}</p>}
              <button type="submit" disabled={saving} className="btn-primary w-full text-xs">
                {saving ? (<><Loader2 size={14} className="animate-spin" /> Saving...</>) : (<><Check size={14} /> Save Details</>)}
              </button>
            </form>
            <div className="border-t border-gold-soft mt-6 pt-5">
              <Link to="/booking" className="flex items-center justify-between text-sm text-cream hover:text-gold transition-colors group">Book an Experience <ArrowRight size={15} className="group-hover:translate-x-1 transition-transform" /></Link>
              <Link to="/support" className="flex items-center justify-between text-sm text-cream hover:text-gold transition-colors mt-3 group">Concierge Support <ArrowRight size={15} className="group-hover:translate-x-1 transition-transform" /></Link>
              <button onClick={handleSignOut} className="flex items-center justify-between text-sm text-cream-dim hover:text-cream transition-colors mt-3 w-full">Sign Out <ArrowRight size={15} /></button>
            </div>
          </div>
          <div className="lg:col-span-2">
            <div className="flex gap-1 mb-6 border-b border-gold-soft">
              <button onClick={() => setTab("reservations")} className={`flex items-center gap-2 px-5 py-3 text-xs tracking-[0.15em] uppercase border-b-2 -mb-px transition-colors ${tab === "reservations" ? "text-gold border-gold" : "text-cream-dim border-transparent hover:text-cream"}`}>
                <Calendar size={14} /> My Reservations ({reservations.length})
              </button>
              <button onClick={() => setTab("tickets")} className={`flex items-center gap-2 px-5 py-3 text-xs tracking-[0.15em] uppercase border-b-2 -mb-px transition-colors ${tab === "tickets" ? "text-gold border-gold" : "text-cream-dim border-transparent hover:text-cream"}`}>
                <Ticket size={14} /> Support Tickets ({tickets.length})
              </button>
            </div>
            {loadingLists ? (
              <p className="text-center text-cream-dim py-20 font-italiana tracking-[0.3em]">LOADING</p>
            ) : tab === "reservations" ? (
              reservations.length === 0 ? (
                <div className="bg-card p-10 text-center border-gold-soft border">
                  <Calendar size={32} className="text-gold mx-auto mb-3 opacity-50" />
                  <p className="text-cream-dim mb-6 font-light">No reservations yet.</p>
                  <Link to="/booking" className="btn-primary text-xs">Book Your First Experience</Link>
                </div>
              ) : (
                <div className="space-y-4">
                  {reservations.map((r) => (
                    <div key={r.id} className="bg-card p-5 border-gold-soft border hover:border-gold transition-all">
                      <div className="flex flex-wrap items-start justify-between gap-4">
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-display text-xl text-cream">{r.service_name}</h3>
                            {r.status && (<span className={`text-[10px] tracking-[0.2em] uppercase px-2 py-0.5 border ${statusClasses(r.status)}`}>{r.status}</span>)}
                          </div>
                          <p className="text-xs text-cream-dim space-x-4">
                            <span className="inline-flex items-center gap-1"><Calendar size={12} className="text-gold" /> {formatDate(r.date)}</span>
                            <span className="inline-flex items-center gap-1"><Clock size={12} className="text-gold" /> {r.time}</span>
                            <span className="inline-flex items-center gap-1">Res. No. CP-{String(r.id).padStart(4, "0")}</span>
                          </p>
                          {r.notes && (<p className="mt-2 text-xs text-cream-dim italic border-l-2 border-gold-soft pl-3">{r.notes}</p>)}
                        </div>
                        {(r.status === "pending" || r.status === "confirmed") && (
                          <button onClick={() => cancelReservation(r)} disabled={cancelling === r.id} className="px-3 py-1.5 text-xs border-gold-soft border text-cream-dim hover:text-gold hover:border-gold transition-colors flex items-center gap-1 disabled:opacity-40">
                            {cancelling === r.id ? (<Loader2 size={13} className="animate-spin" />) : (<X size={13} />)} Cancel
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )
            ) : tickets.length === 0 ? (
              <div className="bg-card p-10 text-center border-gold-soft border">
                <Ticket size={32} className="text-gold mx-auto mb-3 opacity-50" />
                <p className="text-cream-dim mb-6 font-light">No support tickets yet.</p>
                <Link to="/support" className="btn-primary text-xs">Open a Ticket</Link>
              </div>
            ) : (
              <div className="space-y-4">
                {tickets.map((t) => (
                  <div key={t.id} className="bg-card p-5 border-gold-soft border">
                    <div className="flex items-start justify-between gap-4 mb-2">
                      <h3 className="font-display text-lg text-cream">{t.subject || "Support Request"}</h3>
                      {t.status && (<span className={`text-[10px] tracking-[0.2em] uppercase px-2 py-0.5 border flex-shrink-0 ${statusClasses(t.status)}`}>{t.status}</span>)}
                    </div>
                    <p className="text-xs text-cream-dim mb-3">{t.category} {t.priority ? `\u00b7 ${t.priority}` : ""}</p>
                    <p className="text-sm text-cream-dim font-light mb-3">{t.message}</p>
                    {t.response && (
                      <div className="border-l-2 border-gold pl-3 mt-3">
                        <p className="text-[10px] tracking-wider uppercase text-gold mb-1 flex items-center gap-1"><FileText size={11} /> Concierge Response</p>
                        <p className="text-sm text-cream font-light">{t.response}</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
