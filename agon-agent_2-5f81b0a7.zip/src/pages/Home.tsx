import { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight, BadgeCheck, ChevronLeft, ChevronRight, Film, Gem, Image as ImageIcon, Play, ShieldCheck, Sparkles, Star, X } from "lucide-react";
import Ornament from "../components/Ornament";
import { formatPrice } from "../lib/format";
import type { MediaItem, Service } from "../lib/types";

const fadeUp = {
  initial: { opacity: 0, y: 30 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: "-60px" },
  transition: { duration: 0.7 },
} as const;

const pillars = [
  { icon: ShieldCheck, title: "Discretion", text: "Your privacy is our highest vow. Every interaction is conducted with the utmost confidentiality \u2014 from initial inquiry to final parting." },
  { icon: Sparkles, title: "Refinement", text: "Our companions are hand-selected for their refinement, intelligence, and grace. Each one embodies the sophistication of the Charlotte Prestige standard." },
  { icon: Gem, title: "Bespoke", text: "No two encounters are alike. We tailor every detail to your desires \u2014 venue, ambiance, conversation, and company." },
];

const steps = [
  { n: "01", title: "Begin", text: "A discreet introduction to our concierge, in person or by message." },
  { n: "02", title: "Match", text: "We match your desires to one of our refined companions." },
  { n: "03", title: "Compose", text: "Every detail \u2014 venue, ambiance, timing \u2014 handled with care." },
  { n: "04", title: "Indulge", text: "An evening \u2014 or weekend \u2014 beyond expectation." },
];

export default function Home() {
  const [services, setServices] = useState<Service[]>([]);
  const [media, setMedia] = useState<MediaItem[]>([]);
  const [heroIndex, setHeroIndex] = useState(0);
  const [lightbox, setLightbox] = useState<MediaItem | null>(null);

  useEffect(() => {
    fetch("/api/services").then((r) => (r.ok ? r.json() : [])).then((d) => setServices(Array.isArray(d) ? d : [])).catch(() => {});
    fetch("/api/homepage-media?active=true").then((r) => (r.ok ? r.json() : [])).then((d) => setMedia(Array.isArray(d) ? d : [])).catch(() => {});
  }, []);

  const featured = services.filter((s) => s.featured).slice(0, 4);
  const showcase = featured.length > 0 ? featured : services.slice(0, 4);
  const gallery = media.length > 0 ? media : null;
  const hero = gallery ? gallery[heroIndex % gallery.length] : null;

  useEffect(() => {
    if (!gallery || gallery.length < 2) return;
    const t = window.setInterval(() => setHeroIndex((i) => (i + 1) % gallery.length), 8000);
    return () => window.clearInterval(t);
  }, [gallery]);

  const closeLightbox = useCallback(() => setLightbox(null), []);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") closeLightbox(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [closeLightbox]);

  return (
    <div className="bg-royal">
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {hero ? (
          hero.media_type === "video" ? (
            <video key={hero.id} src={hero.file_url} autoPlay muted loop playsInline className="absolute inset-0 w-full h-full object-cover animate-hero" />
          ) : (
            <img key={hero.id} src={hero.file_url} alt={hero.title || "Charlotte Prestige"} className="absolute inset-0 w-full h-full object-cover animate-hero" />
          )
        ) : (
          <img src="/images/hero.jpg" alt="Charlotte Prestige" className="absolute inset-0 w-full h-full object-cover" />
        )}
        <div className="absolute inset-0 hero-overlay" />
        <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1 }} className="relative z-10 max-w-6xl mx-auto px-6 text-center pt-24">
          <div className="ornament-line mb-8 justify-center"><Ornament>By appointment only</Ornament></div>
          <h1 className="font-italiana text-gradient-gold text-5xl sm:text-7xl lg:text-8xl mb-6">CHARLOTTE PRESTIGE</h1>
          <p className="font-display italic text-xl sm:text-2xl text-cream-dim max-w-2xl mx-auto mb-3">Where discretion meets desire.</p>
          <p className="text-sm text-cream-dim max-w-xl mx-auto mb-10 leading-relaxed font-light">A bespoke concierge for those who seek the extraordinary. Every encounter curated. Every detail attended to. Every moment yours to command.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link to="/booking" className="btn-primary">Reserve Now <ArrowRight size={16} /></Link>
            <Link to="/services" className="btn-secondary">Explore Experiences</Link>
          </div>
          {hero?.title && (<p className="mt-8 text-[11px] tracking-[0.3em] uppercase text-cream-dim/80">{hero.title}</p>)}
        </motion.div>
        {gallery && gallery.length > 1 && (
          <div className="absolute bottom-24 left-1/2 -translate-x-1/2 z-10 flex items-center gap-3">
            <button onClick={() => setHeroIndex((i) => (i - 1 + gallery.length) % gallery.length)} className="p-2 text-cream-dim hover:text-gold transition-colors" aria-label="Previous"><ChevronLeft size={20} /></button>
            <div className="flex items-center gap-2">
              {gallery.map((m, i) => (
                <button key={m.id} onClick={() => setHeroIndex(i)} aria-label={`Slide ${i + 1}`} className={`h-1 transition-all duration-500 ${i === heroIndex % gallery.length ? "w-8 bg-gold" : "w-3 bg-cream-dim/40 hover:bg-cream-dim"}`} />
              ))}
            </div>
            <button onClick={() => setHeroIndex((i) => (i + 1) % gallery.length)} className="p-2 text-cream-dim hover:text-gold transition-colors" aria-label="Next"><ChevronRight size={20} /></button>
          </div>
        )}
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-3 z-10">
          <span className="text-[10px] tracking-[0.3em] uppercase text-cream-dim">Discover</span>
          <span className="w-px h-16 bg-gradient-to-b from-transparent via-gold to-transparent" />
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-6 lg:px-10 py-16">
        <div className="text-center mb-16">
          <div className="ornament-line mb-6 justify-center"><Ornament>The Charlotte Prestige Difference</Ornament></div>
          <h2 className="font-display text-4xl sm:text-5xl text-cream mb-4">A House of Distinction</h2>
          <p className="text-cream-dim max-w-xl mx-auto font-light">For over a decade we have refined the craft of companionship \u2014 where every detail is considered, every preference honored, every moment elevated.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {pillars.map((p, i) => (
            <motion.div key={p.title} {...fadeUp} transition={{ duration: 0.7, delay: i * 0.12 }} className="bg-card p-8 hover:bg-card-hover transition-all duration-500 group">
              <p.icon size={28} className="text-gold mb-5 group-hover:scale-110 transition-transform" />
              <h3 className="font-display text-2xl text-cream mb-3">{p.title}</h3>
              <p className="text-sm text-cream-dim font-light leading-relaxed">{p.text}</p>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-6 lg:px-10 py-16">
        <div className="text-center mb-16">
          <div className="ornament-line mb-6 justify-center"><Ornament>The Collection</Ornament></div>
          <h2 className="font-display text-4xl sm:text-5xl text-cream mb-4">Signature Experiences</h2>
          <p className="text-cream-dim max-w-xl mx-auto font-light">Each offering is a chapter in our ongoing story of refined companionship.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {showcase.map((s, i) => (
            <motion.div key={s.id} {...fadeUp} transition={{ duration: 0.7, delay: i * 0.1 }}>
              <Link to={`/booking?service=${s.id}`} className="group relative block overflow-hidden border border-gold-soft hover:border-gold transition-all duration-500 aspect-[3/4]">
                {s.image_url && (<img src={s.image_url} alt={s.name} loading="lazy" className="absolute inset-0 w-full h-full object-cover opacity-50 group-hover:opacity-70 group-hover:scale-105 transition-all duration-700" />)}
                <div className="absolute inset-0 bg-gradient-to-t from-[#0a0908f5] via-[#0a090866] to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-6">
                  <h3 className="font-display text-2xl text-cream mb-2">{s.name}</h3>
                  <p className="text-xs text-cream-dim mb-4 font-light line-clamp-2">{s.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-cream font-display text-lg">{formatPrice(s.price)}</span>
                    <span className="text-xs text-gold tracking-wider uppercase flex items-center gap-1">Reserve <ArrowRight size={14} /></span>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
        <div className="text-center mt-10">
          <Link to="/services" className="btn-secondary">View All Services <ArrowRight size={16} /></Link>
        </div>
      </section>

      {gallery && gallery.length > 0 && (
        <section className="max-w-7xl mx-auto px-6 lg:px-10 py-16">
          <div className="text-center mb-12">
            <div className="ornament-line mb-6 justify-center"><Ornament>Moments</Ornament></div>
            <h2 className="font-display text-4xl sm:text-5xl text-cream mb-4">Captured at the House</h2>
            <p className="text-cream-dim max-w-xl mx-auto font-light">Glimpses of evenings composed, journeys shared, and atmospheres we create for our distinguished members.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {gallery.map((m, i) => (
              <motion.div key={m.id} {...fadeUp} transition={{ duration: 0.6, delay: (i % 3) * 0.1 }}>
                <button onClick={() => setLightbox(m)} className="group relative block w-full overflow-hidden border border-gold-soft hover:border-gold transition-all duration-500 aspect-video text-left">
                  {m.media_type === "video" ? (
                    <>
                      <video src={m.file_url} muted playsInline preload="metadata" className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:opacity-80 group-hover:scale-105 transition-all duration-700" />
                      <span className="absolute inset-0 flex items-center justify-center">
                        <span className="w-14 h-14 rounded-full flex items-center justify-center border border-gold bg-[#0a0908aa]"><Play size={20} className="text-gold ml-0.5" /></span>
                      </span>
                      <span className="absolute top-3 left-3 flex items-center gap-1 text-[10px] tracking-[0.2em] uppercase text-gold border border-gold px-2 py-1 bg-[#0a0908aa]"><Film size={11} /> Film</span>
                    </>
                  ) : (
                    <>
                      <img src={m.file_url} alt={m.title || "Gallery image"} loading="lazy" className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:opacity-80 group-hover:scale-105 transition-all duration-700" />
                      <span className="absolute top-3 left-3 flex items-center gap-1 text-[10px] tracking-[0.2em] uppercase text-gold border border-gold px-2 py-1 bg-[#0a0908aa]"><ImageIcon size={11} /> Image</span>
                    </>
                  )}
                  <span className="absolute inset-0 bg-gradient-to-t from-[#0a0908ee] via-transparent to-transparent" />
                  <span className="absolute inset-x-0 bottom-0 p-5 block">
                    <span className="font-display text-xl text-cream block">{m.title}</span>
                    {m.description && (<span className="text-xs text-cream-dim font-light line-clamp-2 block mt-1">{m.description}</span>)}
                  </span>
                </button>
              </motion.div>
            ))}
          </div>
        </section>
      )}

      <section className="max-w-7xl mx-auto px-6 lg:px-10 py-16">
        <div className="text-center mb-16">
          <div className="ornament-line mb-6 justify-center"><Ornament>The Process</Ornament></div>
          <h2 className="font-display text-4xl sm:text-5xl text-cream mb-4">Effortless from Beginning to End</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {steps.map((s, i) => (
            <motion.div key={s.n} {...fadeUp} transition={{ duration: 0.7, delay: i * 0.12 }} className="relative text-center md:text-left">
              <p className="text-gold font-italiana text-5xl mb-3 opacity-50">{s.n}</p>
              <h3 className="font-display text-xl text-cream mb-2">{s.title}</h3>
              <p className="text-sm text-cream-dim font-light leading-relaxed">{s.text}</p>
              {i < steps.length - 1 && (<span className="hidden md:block absolute top-8 -right-3 w-6 h-px bg-gradient-to-r from-gold to-transparent" />)}
            </motion.div>
          ))}
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-6 lg:px-10 py-16">
        <div className="text-center mb-12">
          <div className="ornament-line mb-6 justify-center"><Ornament>Words from Our Patrons</Ornament></div>
        </div>
        <motion.div {...fadeUp} className="bg-card p-12 md:p-16 relative border-gold-soft border max-w-4xl mx-auto text-center">
          <div className="flex justify-center gap-1 mb-6">
            {[0, 1, 2, 3, 4].map((i) => (<Star key={i} size={16} className="text-gold" fill="#c9a961" />))}
          </div>
          <p className="font-display italic text-2xl md:text-3xl text-cream leading-relaxed mb-8">\u201cCharlotte Prestige has redefined what I thought possible. The level of detail, the discretion, the sheer refinement \u2014 it is unlike anything else. Every encounter is masterfully composed.\u201d</p>
          <p className="font-display text-xl text-gold">A Distinguished Member</p>
          <p className="text-xs text-cream-dim tracking-wider mt-1 flex items-center justify-center gap-1"><BadgeCheck size={13} className="text-gold" /> Verified Patron</p>
        </motion.div>
      </section>

      <section className="max-w-7xl mx-auto px-6 lg:px-10 py-16">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="font-display text-4xl sm:text-6xl text-cream mb-6">Your story awaits.</h2>
          <p className="text-cream-dim max-w-xl mx-auto mb-10 font-light leading-relaxed">A conversation is all it takes. Our concierge stands ready, day or night, to begin curating something unforgettable.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/booking" className="btn-primary">Book an Experience</Link>
            <Link to="/contact" className="btn-secondary">Speak to Concierge</Link>
          </div>
        </div>
      </section>

      {lightbox && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 sm:p-8">
          <div className="absolute inset-0 bg-[#0a0908f2]" onClick={closeLightbox} />
          <button onClick={closeLightbox} className="absolute top-5 right-5 p-2 text-cream-dim hover:text-gold transition-colors z-10" aria-label="Close"><X size={26} /></button>
          <div className="relative max-w-5xl w-full max-h-[88vh] flex flex-col animate-fade-slide">
            <div className="border border-gold-soft bg-[#0a0908] overflow-hidden flex items-center justify-center">
              {lightbox.media_type === "video" ? (
                <video src={lightbox.file_url} controls autoPlay playsInline className="w-full max-h-[74vh]" />
              ) : (
                <img src={lightbox.file_url} alt={lightbox.title || "Gallery image"} className="w-full h-auto object-contain" style={{ maxHeight: "74vh" }} />
              )}
            </div>
            <div className="pt-4 text-center">
              <p className="font-display text-2xl text-cream">{lightbox.title}</p>
              {lightbox.description && <p className="text-sm text-cream-dim font-light mt-1">{lightbox.description}</p>}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
