import { useEffect, useState } from "react";
import type { FormEvent } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { CalendarCheck, CheckCircle, ChevronDown, HelpCircle, Loader2, MessageCircle, Send, Ticket } from "lucide-react";
import Ornament from "../components/Ornament";
import { useAuth } from "../contexts/AuthContext";
import { openLiveChat } from "../lib/format";

const faqs = [
  { q: "How do I make a reservation?", a: "Navigate to our Reservations page, choose your experience, select a date and time, and provide a few details. Our concierge will confirm your booking personally within hours." },
  { q: "What is your cancellation policy?", a: "Cancellations made more than 48 hours in advance are fully refundable. Within 48 hours, we offer rescheduling at no charge. Companions are vetted and available with proper notice." },
  { q: "How is my privacy protected?", a: "Discretion is our highest principle. Communications are end-to-end encrypted. Personal information is never stored on third-party platforms and is purged after your engagement concludes." },
  { q: "What if I need to change my booking?", a: "Simply open a support ticket or message us via the live chat. Our concierge is available 24/7 to accommodate changes discreetly." },
  { q: "Are companions vetted?", a: "Every companion in our collection is personally interviewed, reference-checked, and trained to the Charlotte Prestige standard of refinement, intelligence, and discretion." },
  { q: "Do you offer international services?", a: "Yes. Our house serves distinguished members across North America, Europe, and the Middle East. Travel companions can be arranged for destination experiences worldwide." },
];

const categories = ["General", "Reservations", "Membership", "Payment", "Other"];
const priorities = ["Normal", "High", "Urgent"];

export default function Support() {
  const { user, profile } = useAuth();
  const [openFaq, setOpenFaq] = useState(0);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [subject, setSubject] = useState("");
  const [category, setCategory] = useState(categories[0]);
  const [priority, setPriority] = useState(priorities[0]);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  useEffect(() => {
    if (user?.email) setEmail((v) => v || user.email || "");
    if (profile?.display_name) setName((v) => v || profile.display_name || "");
  }, [user, profile]);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !message.trim()) { setError("Please provide your name, email, and message."); return; }
    setError("");
    setSending(true);
    try {
      const res = await fetch("/api/support", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name.trim(), email: email.trim(), subject: subject.trim(), category, priority, message: message.trim() }),
      });
      if (!res.ok) throw new Error("send failed");
      setSent(true);
    } catch {
      setError("Failed to send. Please try again.");
    } finally {
      setSending(false);
    }
  };

  const reset = () => { setSent(false); setName(""); setEmail(""); setSubject(""); setCategory(categories[0]); setPriority(priorities[0]); setMessage(""); };

  return (
    <div className="bg-royal pt-32 pb-20 min-h-screen px-6">
      <div className="max-w-6xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
          <div className="ornament-line mb-6 justify-center"><Ornament>Assist</Ornament></div>
          <h1 className="font-display text-5xl sm:text-6xl text-cream mb-4">Concierge Support</h1>
          <p className="text-cream-dim font-light">Answers, assistance, and attentive care \u2014 always at hand.</p>
        </motion.div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-12">
          <a href="#ticket" className="bg-card p-6 border-gold-soft border hover:border-gold transition-all group text-left">
            <Ticket size={24} className="text-gold mb-4 group-hover:scale-110 transition-transform" />
            <h3 className="font-display text-lg text-cream mb-1 group-hover:text-gold transition-colors">Open a Ticket</h3>
            <p className="text-xs text-cream-dim font-light">For detailed inquiries and written correspondence.</p>
          </a>
          <button onClick={openLiveChat} className="bg-card p-6 border-gold-soft border hover:border-gold transition-all group text-left">
            <MessageCircle size={24} className="text-gold mb-4 group-hover:scale-110 transition-transform" />
            <h3 className="font-display text-lg text-cream mb-1 group-hover:text-gold transition-colors">Live Chat</h3>
            <p className="text-xs text-cream-dim font-light">Instant conversation with our concierge team.</p>
          </button>
          <Link to="/booking" className="bg-card p-6 border-gold-soft border hover:border-gold transition-all group">
            <CalendarCheck size={24} className="text-gold mb-4 group-hover:scale-110 transition-transform" />
            <h3 className="font-display text-lg text-cream mb-1 group-hover:text-gold transition-colors">Reservations</h3>
            <p className="text-xs text-cream-dim font-light">Make or amend a reservation with our concierge.</p>
          </Link>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <motion.div initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.6 }}>
            <div className="flex items-center gap-3 mb-6">
              <HelpCircle size={24} className="text-gold" />
              <h2 className="font-display text-3xl text-cream">Frequently Asked</h2>
            </div>
            <div className="space-y-3">
              {faqs.map((f, i) => {
                const open = openFaq === i;
                return (
                  <div key={f.q} className="bg-card border-gold-soft border overflow-hidden">
                    <button onClick={() => setOpenFaq(open ? -1 : i)} className="w-full flex items-center justify-between gap-4 p-5 text-left">
                      <span className="font-display text-lg text-cream">{f.q}</span>
                      <ChevronDown size={18} className={`text-gold flex-shrink-0 transition-transform ${open ? "rotate-180" : ""}`} />
                    </button>
                    {open && (<p className="px-5 pb-5 text-sm text-cream-dim font-light leading-relaxed border-t border-gold-soft pt-4 animate-fade-slide">{f.a}</p>)}
                  </div>
                );
              })}
            </div>
          </motion.div>
          <motion.div id="ticket" initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.6 }} className="scroll-mt-28">
            <div className="flex items-center gap-3 mb-6">
              <Ticket size={24} className="text-gold" />
              <h2 className="font-display text-3xl text-cream">Open a Ticket</h2>
            </div>
            {sent ? (
              <div className="bg-card p-10 border-gold-soft border text-center">
                <div className="w-16 h-16 mx-auto mb-6 rounded-full flex items-center justify-center border border-gold"><CheckCircle size={28} className="text-gold" /></div>
                <h3 className="font-display text-3xl text-cream mb-3">Ticket Submitted</h3>
                <p className="text-cream-dim font-light mb-8">Our team will respond via email or live chat shortly.</p>
                <button onClick={reset} className="btn-secondary text-xs">Submit Another</button>
              </div>
            ) : (
              <form onSubmit={submit} className="bg-card p-7 border-gold-soft border space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="label-royal">Your Name</label>
                    <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Your full name" className="input-royal" />
                  </div>
                  <div>
                    <label className="label-royal">Email</label>
                    <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" className="input-royal" />
                  </div>
                </div>
                <div>
                  <label className="label-royal">Subject</label>
                  <input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="How may we assist?" className="input-royal" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="label-royal">Category</label>
                    <select value={category} onChange={(e) => setCategory(e.target.value)} className="input-royal">
                      {categories.map((c) => (<option key={c} value={c}>{c}</option>))}
                    </select>
                  </div>
                  <div>
                    <label className="label-royal">Priority</label>
                    <select value={priority} onChange={(e) => setPriority(e.target.value)} className="input-royal">
                      {priorities.map((p) => (<option key={p} value={p}>{p}</option>))}
                    </select>
                  </div>
                </div>
                <div>
                  <label className="label-royal">Message</label>
                  <textarea value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Describe your request..." rows={5} className="input-royal resize-none" />
                </div>
                {error && <p className="text-sm text-danger">{error}</p>}
                <button type="submit" disabled={sending} className="btn-primary w-full text-xs">
                  {sending ? (<><Loader2 size={15} className="animate-spin" /> Sending...</>) : (<><Send size={14} /> Submit Ticket</>)}
                </button>
              </form>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
}
