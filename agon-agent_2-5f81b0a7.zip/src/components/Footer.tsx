import { Link } from "react-router-dom";
import { Clock, Facebook, Instagram, Mail, Phone, Twitter } from "lucide-react";
import { LogoMark } from "./Navbar";

const experiences = ["Private Companionship", "Weekend Retreat", "Travel Companion", "Couples Experience", "Event Hosting", "Bespoke Experiences"];
const navigate = [
  { to: "/", label: "Home" },
  { to: "/about", label: "The House" },
  { to: "/services", label: "Experiences" },
  { to: "/booking", label: "Reservations" },
  { to: "/support", label: "Support" },
  { to: "/contact", label: "Contact" },
];

export default function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="border-t border-gold-soft bg-[#070605]">
      <div className="max-w-7xl mx-auto px-6 lg:px-10 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          <div>
            <div className="flex items-center gap-3 mb-5">
              <LogoMark size={32} />
              <div className="flex flex-col leading-none">
                <span className="font-italiana text-cream tracking-[0.2em]">CHARLOTTE</span>
                <span className="text-[9px] text-gold tracking-[0.28em] uppercase mt-1">Prestige Management</span>
              </div>
            </div>
            <p className="text-sm text-cream-dim leading-relaxed font-light">An intimate concierge for the discerning. Discretion, refinement, and an unwavering commitment to the extraordinary.</p>
            <p className="text-xs text-cream-dim tracking-wider mt-4">Est. Anno MMXXV \u00b7 By appointment only</p>
            <div className="flex items-center gap-3 mt-5">
              <a href="#" aria-label="Instagram" className="text-cream-dim hover:text-gold transition-colors"><Instagram size={18} /></a>
              <a href="#" aria-label="Twitter" className="text-cream-dim hover:text-gold transition-colors"><Twitter size={18} /></a>
              <a href="#" aria-label="Facebook" className="text-cream-dim hover:text-gold transition-colors"><Facebook size={18} /></a>
            </div>
            <Link to="/admin" className="flex items-center gap-3 mt-6 pt-5 border-t border-gold-soft group">
              <div className="w-12 h-12 rounded-full border border-gold flex-shrink-0 flex items-center justify-center font-italiana text-xl text-gold group-hover:bg-gold-soft transition-colors">A</div>
              <div className="flex flex-col leading-tight">
                <span className="text-sm text-cream tracking-wide">Admin</span>
                <span className="text-[10px] text-gold tracking-[0.28em] uppercase mt-1">Site Administrator</span>
              </div>
            </Link>
          </div>
          <div>
            <h4 className="font-display text-xl text-cream mb-5">Navigate</h4>
            <ul className="space-y-3">
              {navigate.map((n) => (<li key={n.to}><Link to={n.to} className="text-sm text-cream-dim hover:text-gold transition-colors font-light">{n.label}</Link></li>))}
            </ul>
          </div>
          <div>
            <h4 className="font-display text-xl text-cream mb-5">Experiences</h4>
            <ul className="space-y-3">
              {experiences.map((e) => (<li key={e}><Link to="/services" className="text-sm text-cream-dim hover:text-gold transition-colors font-light">{e}</Link></li>))}
            </ul>
          </div>
          <div>
            <h4 className="font-display text-xl text-cream mb-5">Reach Us</h4>
            <ul className="space-y-4">
              <li className="flex items-center gap-3 text-sm text-cream-dim font-light">
                <Phone size={16} className="text-gold flex-shrink-0" />
                <a href="tel:+18885550192" className="hover:text-gold transition-colors">+1 (888) 555-0192</a>
              </li>
              <li className="flex items-center gap-3 text-sm text-cream-dim font-light">
                <Mail size={16} className="text-gold flex-shrink-0" />
                <a href="mailto:concierge@charlotteprestige.com" className="hover:text-gold transition-colors">concierge@charlotteprestige.com</a>
              </li>
              <li className="flex items-start gap-3 text-sm text-cream-dim font-light">
                <Clock size={16} className="text-gold flex-shrink-0 mt-0.5" />
                <span>Concierge always available <span className="text-cream">\u2014 day &amp; night, every day.</span></span>
              </li>
            </ul>
          </div>
        </div>
        <div className="border-t border-gold-soft mt-12 pt-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-xs text-cream-dim tracking-wider">\u00a9 {year} Charlotte Prestige Management. All rights reserved.</p>
            <div className="flex items-center gap-6">
              <Link to="/support" className="text-xs text-cream-dim hover:text-gold transition-colors tracking-wider">Support</Link>
              <Link to="/contact" className="text-xs text-cream-dim hover:text-gold transition-colors tracking-wider">Contact</Link>
              <Link to="/booking" className="text-xs text-cream-dim hover:text-gold transition-colors tracking-wider">Reservations</Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
