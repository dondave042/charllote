import type { ReactNode } from "react";

export default function Ornament({ children }: { children: ReactNode }) {
  return (
    <span className="ornament-line">
      <span className="w-6 h-px bg-gold inline-block opacity-60" />
      {children}
      <span className="w-6 h-px bg-gold inline-block opacity-60" />
    </span>
  );
}
