import { useEffect, useState } from "react";
import { Link, NavLink, useLocation, useNavigate } from "react-router-dom";
import { ChevronDown, LayoutDashboard, LogOut, Menu, User, X } from "lucide-react";
import { useAuth } from "../contexts/AuthContext";

export function LogoMark({ size = 36 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M30 8 L35 22 L50 22 L39 31 L43 46 L30 38 L17 46 L21 31 L10 22 L25 22 Z" stroke="#c9a961" strokeWidth="1.5" fill="none" />
      <circle cx="30" cy="28" r="3" fill="#c9a961" />
    </svg>
  );
}

const links = [
  { to: "/about", label: "The House" },
  { to: "/services", label: "Experiences" },
  { to: "/booking", label: "Reservations" },
  { to: "/support", label: "Support" },
  { to: "/contact", label: "Contact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [dropOpen, setDropOpen] = useState(false);
  const { user, profile, isAdmin, signOut } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
    setDropOpen(false);
  }, [location.pathname]);

  const handleSignOut = async () => {
    await signOut();
    navigate("/");
  };

  const displayName = profile?.display_name || user?.email?.split("@")[0] || "Member";

  return (
    <header className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ${scrolled ? "bg-[#0a0908f2] backdrop-blur-md border-b border-gold-soft" : "bg-transparent"}`}>
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="flex items-center justify-between h-20">
          <Link to="/" className="flex items-center gap-3 group">
            <div className="transition-transform group-hover:scale-105">
              <LogoMark />
            </div>
            <span className="flex flex-col leading-none">
              <span className="font-italiana text-cream text-lg tracking-[0.2em]">CHARLOTTE</span>
              <span className="text-[10px] text-gold tracking-[0.28em] uppercase mt-1">Prestige Management</span>
            </span>
          </Link>
          <nav className="hidden lg:flex items-center gap-8">
            {links.map((l) => (
              <NavLink key={l.to} to={l.to} className={({ isActive }) => `relative text-sm tracking-wide transition-colors ${isActive ? "text-gold" : "text-cream-dim hover:text-cream"}`}>
                {({ isActive }) => (<>{l.label}{isActive && <span className="absolute -bottom-1 left-0 right-0 h-px bg-gold" />}</>)}
              </NavLink>
            ))}
          </nav>
          <div className="hidden lg:flex items-center gap-4">
            {user ? (
              <div className="relative">
                <button onClick={() => setDropOpen((v) => !v)} className="flex items-center gap-2 px-3 py-2 border-gold-soft border hover:border-gold transition-colors">
                  <User size={16} className="text-gold" />
                  <span className="text-sm text-cream tracking-wide">{displayName}</span>
                  <ChevronDown size={14} className={`text-cream-dim transition-transform ${dropOpen ? "rotate-180" : ""}`} />
                </button>
                {dropOpen && (
                  <div className="absolute right-0 top-full mt-2 w-56 bg-card border border-gold-soft backdrop-blur-md z-50">
                    <Link to="/profile" className="px-4 py-3 text-sm text-cream tracking-wide hover:bg-gold-soft transition-colors flex items-center gap-2">
                      <User size={15} className="text-gold" /> My Profile
                    </Link>
                    {isAdmin && (
                      <Link to="/admin" className="px-4 py-3 text-sm text-cream tracking-wide hover:bg-gold-soft transition-colors flex items-center gap-2">
                        <LayoutDashboard size={15} className="text-gold" /> Admin Dashboard
                      </Link>
                    )}
                    <div className="border-t border-gold-soft mt-3 pt-3 flex flex-col gap-2">
                      <button onClick={handleSignOut} className="text-left px-4 py-3 text-sm text-cream-dim hover:text-cream transition-colors flex items-center gap-2">
                        <LogOut size={15} /> Sign Out
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <>
                <Link to="/login" className="text-sm text-cream-dim hover:text-cream tracking-wide transition-colors">Sign In</Link>
                <Link to="/booking" className="btn-primary text-xs py-2.5 px-5">Reserve</Link>
              </>
            )}
          </div>
          <button onClick={() => setMenuOpen((v) => !v)} className="lg:hidden p-2 text-cream" aria-label="Menu">
            {menuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>
      {menuOpen && (
        <div className="lg:hidden bg-[#0a0908f8] border-t border-gold-soft backdrop-blur-md">
          <div className="px-6 py-6 flex flex-col gap-1">
            {links.map((l) => (
              <NavLink key={l.to} to={l.to} className={({ isActive }) => `px-4 py-3 text-sm tracking-wide transition-colors ${isActive ? "text-gold" : "text-cream-dim hover:text-cream"}`}>
                {l.label}
              </NavLink>
            ))}
            <div className="border-t border-gold-soft mt-3 pt-3 flex flex-col gap-2">
              {user ? (
                <>
                  <Link to="/profile" className="px-4 py-3 text-sm text-cream tracking-wide">My Profile</Link>
                  {isAdmin && (<Link to="/admin" className="px-4 py-3 text-sm text-cream tracking-wide">Admin Dashboard</Link>)}
                  <button onClick={handleSignOut} className="text-left px-4 py-3 text-sm text-cream-dim">Sign Out</button>
                </>
              ) : (
                <>
                  <Link to="/login" className="px-4 py-3 text-sm text-cream tracking-wide">Sign In</Link>
                  <Link to="/booking" className="mx-4 btn-primary text-xs mt-2">Reserve</Link>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
