import { Navigate } from "react-router-dom";
import type { ReactElement } from "react";
import { useAuth } from "../contexts/AuthContext";

export default function ProtectedRoute({ children }: { children: ReactElement }) {
  const { user, loading } = useAuth();
  if (loading) {
    return (
      <div className="bg-royal min-h-screen flex items-center justify-center">
        <p className="font-italiana text-2xl text-gradient-gold tracking-[0.3em]">LOADING</p>
      </div>
    );
  }
  if (!user) return <Navigate to="/login" replace />;
  return children;
}
